﻿using System;
using System.Collections.Generic;

using System.Text;

namespace ControlExs
{
    public enum ClassStyle 
    {
        CS_DropSHADOW = 0x20000  //实现窗体阴影
    }
}
