﻿using System;
using System.Collections.Generic;

using System.Text;

namespace ControlExs
{
    public enum SystemButtonState
    {
        Normal,
        HighLight,
        Down,
        DownLeave
    }
}
