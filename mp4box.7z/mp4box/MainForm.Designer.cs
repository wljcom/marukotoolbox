﻿namespace mp4box
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtvideo4 = new ControlExs.QQTextBox();
            this.btnvideo4 = new ControlExs.QQButton();
            this.btnout5 = new ControlExs.QQButton();
            this.btnClip = new ControlExs.QQButton();
            this.txtout5 = new ControlExs.QQTextBox();
            this.maske = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.maskb = new System.Windows.Forms.MaskedTextBox();
            this.btnout4 = new ControlExs.QQButton();
            this.cbDelTmp = new ControlExs.QQCheckBox();
            this.MediaInfoTab = new System.Windows.Forms.TabPage();
            this.btnMIopen = new ControlExs.QQButton();
            this.btnMIplay = new ControlExs.QQButton();
            this.btnMIcopy = new ControlExs.QQButton();
            this.txtMI = new System.Windows.Forms.TextBox();
            this.AVSTab = new System.Windows.Forms.TabPage();
            this.AVSSaveButton = new ControlExs.QQButton();
            this.AVSSubCheckBox = new ControlExs.QQCheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.AVSCropTextBox = new ControlExs.QQTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.TrimEndNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TrimStartNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.LevelsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.AddBorders4NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.AddBorders3NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.AddBorders2NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.SharpenNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.AddBorders1NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.AVSHeightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.AVSWidthNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TweakContrastNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TweakBrightnessNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TweakSaturationNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TweakChromaNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAVS = new ControlExs.QQTextBox();
            this.txtvideo9 = new ControlExs.QQTextBox();
            this.txtout9 = new ControlExs.QQTextBox();
            this.txtsub9 = new ControlExs.QQTextBox();
            this.LevelsCheckBox = new ControlExs.QQCheckBox();
            this.CropCheckBox = new ControlExs.QQCheckBox();
            this.TrimCheckBox = new ControlExs.QQCheckBox();
            this.SharpenCheckBox = new ControlExs.QQCheckBox();
            this.AddBordersCheckBox = new ControlExs.QQCheckBox();
            this.LanczosResizeCheckBox = new ControlExs.QQCheckBox();
            this.TweakCheckBox = new ControlExs.QQCheckBox();
            this.UndotCheckBox = new ControlExs.QQCheckBox();
            this.button9 = new ControlExs.QQButton();
            this.button6 = new ControlExs.QQButton();
            this.btnpreview9 = new ControlExs.QQButton();
            this.btnAVSone = new ControlExs.QQButton();
            this.btnAVS9 = new ControlExs.QQButton();
            this.btnvideo9 = new ControlExs.QQButton();
            this.btnout9 = new ControlExs.QQButton();
            this.btnsub9 = new ControlExs.QQButton();
            this.ExtractTab = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.MkvExtract4Button = new ControlExs.QQButton();
            this.MkvExtract3Button = new ControlExs.QQButton();
            this.MkvExtract2Button = new ControlExs.QQButton();
            this.MkvExtract1Button = new ControlExs.QQButton();
            this.btnextract7 = new ControlExs.QQButton();
            this.btnvideo7 = new ControlExs.QQButton();
            this.txtvideo6 = new ControlExs.QQTextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnvextract8 = new ControlExs.QQButton();
            this.btnvideo8 = new ControlExs.QQButton();
            this.txtvideo8 = new ControlExs.QQTextBox();
            this.btnaextract8 = new ControlExs.QQButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ExtractMP4TextBox = new ControlExs.QQTextBox();
            this.btnaextract3 = new ControlExs.QQButton();
            this.ExtractMP4Button = new ControlExs.QQButton();
            this.btnvextract = new ControlExs.QQButton();
            this.btnaextract = new ControlExs.QQButton();
            this.btnaextract2 = new ControlExs.QQButton();
            this.MuxTab = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbffmpeg = new System.Windows.Forms.ListBox();
            this.btnffmpegAdd = new ControlExs.QQButton();
            this.btnffmpegClear = new ControlExs.QQButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnffmpegDel = new ControlExs.QQButton();
            this.btnBatchMP4 = new ControlExs.QQButton();
            this.btnBatchFLV = new ControlExs.QQButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.MuxReplaceAudioButton = new ControlExs.QQButton();
            this.txtvideo = new ControlExs.QQTextBox();
            this.btnvideo = new ControlExs.QQButton();
            this.btnmux = new ControlExs.QQButton();
            this.cbFPS = new System.Windows.Forms.ComboBox();
            this.btnaudio = new ControlExs.QQButton();
            this.btnout = new ControlExs.QQButton();
            this.txtaudio = new ControlExs.QQTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtout = new ControlExs.QQTextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtvideo5 = new ControlExs.QQTextBox();
            this.button4 = new ControlExs.QQButton();
            this.txtsub = new ControlExs.QQTextBox();
            this.button3 = new ControlExs.QQButton();
            this.txtaudio3 = new ControlExs.QQTextBox();
            this.button5 = new ControlExs.QQButton();
            this.txtout6 = new ControlExs.QQTextBox();
            this.button2 = new ControlExs.QQButton();
            this.button7 = new ControlExs.QQButton();
            this.tabNeroAAC = new System.Windows.Forms.TabPage();
            this.NeroAACGroupBox = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.AudioEncoderComboBox = new System.Windows.Forms.ComboBox();
            this.txtaudio2 = new ControlExs.QQTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AudioBitrateRadioButton = new ControlExs.QQRadioButton();
            this.AudioCustomizeRadioButton = new ControlExs.QQRadioButton();
            this.txtout3 = new ControlExs.QQTextBox();
            this.cbwavtemp = new ControlExs.QQCheckBox();
            this.btnaudio2 = new ControlExs.QQButton();
            this.lbaackbps = new System.Windows.Forms.Label();
            this.btnout3 = new ControlExs.QQButton();
            this.lbaacrate = new System.Windows.Forms.Label();
            this.btnaac = new ControlExs.QQButton();
            this.numq = new System.Windows.Forms.NumericUpDown();
            this.txtNeroaac = new ControlExs.QQTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AudioBatchButton = new ControlExs.QQButton();
            this.AudioListBox = new System.Windows.Forms.ListBox();
            this.AudioAddButton = new ControlExs.QQButton();
            this.AudioClearButton = new ControlExs.QQButton();
            this.AudioDeleteButton = new ControlExs.QQButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.OnePicCRFNum = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.AudioCopyCheckBox = new ControlExs.QQCheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.AudioOnePicFPSNum = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.AudioOnePicAudioBitrateNum = new System.Windows.Forms.NumericUpDown();
            this.AudioOnePicOutputButton = new ControlExs.QQButton();
            this.AudioOnePicButton = new ControlExs.QQButton();
            this.AudioPicAudioButton = new ControlExs.QQButton();
            this.AudioPicButton = new ControlExs.QQButton();
            this.AudioOnePicOutputTextBox = new ControlExs.QQTextBox();
            this.AudioPicAudioTextBox = new ControlExs.QQTextBox();
            this.AudioPicTextBox = new ControlExs.QQTextBox();
            this.VideoTab = new System.Windows.Forms.TabPage();
            this.x264FramesLabel = new System.Windows.Forms.Label();
            this.x264SeekLabel = new System.Windows.Forms.Label();
            this.x264FramesNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.x264SeekNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.MaintainResolutionCheckBox = new ControlExs.QQCheckBox();
            this.DemuxerComboBox = new System.Windows.Forms.ComboBox();
            this.x264FLVCheckBox = new ControlExs.QQCheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.x264OneBatchButton = new ControlExs.QQButton();
            this.x264PathButton = new ControlExs.QQButton();
            this.x264PathTextBox = new ControlExs.QQTextBox();
            this.lbAuto = new System.Windows.Forms.ListBox();
            this.x264BatchClearBtn = new ControlExs.QQButton();
            this.x264BatchSubCheckBox = new ControlExs.QQCheckBox();
            this.x264BatchDeleteBtn = new ControlExs.QQButton();
            this.x264BatchAddBtn = new ControlExs.QQButton();
            this.btnBatchAuto = new ControlExs.QQButton();
            this.x264ShutdownCheckBox = new ControlExs.QQCheckBox();
            this.x264AudioParameterTextBox = new ControlExs.QQTextBox();
            this.x264SubTextBox = new ControlExs.QQTextBox();
            this.x264OutTextBox = new ControlExs.QQTextBox();
            this.x264VideoTextBox = new ControlExs.QQTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.x264Mode1RadioButton = new ControlExs.QQRadioButton();
            this.x264Mode3RadioButton = new ControlExs.QQRadioButton();
            this.x264Mode2RadioButton = new ControlExs.QQRadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.PresetNameTextBox = new ControlExs.QQTextBox();
            this.x264AddPresetBtn = new ControlExs.QQButton();
            this.x264DeletePresetBtn = new ControlExs.QQButton();
            this.x264StartBtn = new ControlExs.QQButton();
            this.x264SubBtn = new ControlExs.QQButton();
            this.x264OutBtn = new ControlExs.QQButton();
            this.x264VideoBtn = new ControlExs.QQButton();
            this.label16 = new System.Windows.Forms.Label();
            this.cbx264file = new System.Windows.Forms.ComboBox();
            this.cbFPS2 = new System.Windows.Forms.ComboBox();
            this.lbFPS2 = new System.Windows.Forms.Label();
            this.x264AudioModeComboBox = new System.Windows.Forms.ComboBox();
            this.cbX264 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.labelAudio = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbcrf = new System.Windows.Forms.Label();
            this.lbheight = new System.Windows.Forms.Label();
            this.lbwidth = new System.Windows.Forms.Label();
            this.numheight = new System.Windows.Forms.NumericUpDown();
            this.numwidth = new System.Windows.Forms.NumericUpDown();
            this.numcrf = new System.Windows.Forms.NumericUpDown();
            this.lbrate = new System.Windows.Forms.Label();
            this.txth264 = new ControlExs.QQTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.numrate = new System.Windows.Forms.NumericUpDown();
            this.HelpTab = new System.Windows.Forms.TabPage();
            this.DonateButton = new ControlExs.QQButton();
            this.HelpTextBox = new ControlExs.QQTextBox();
            this.HomePageBtn = new ControlExs.QQButton();
            this.AboutBtn = new ControlExs.QQButton();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.AudioTab = new System.Windows.Forms.TabControl();
            this.MiscTab = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.BlackBitrateNum = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.BlackSecondComboBox = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.BlackCRFNum = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.BlackNoPicCheckBox = new ControlExs.QQCheckBox();
            this.label31 = new System.Windows.Forms.Label();
            this.BlackFPSNum = new System.Windows.Forms.NumericUpDown();
            this.BlackPicButton = new ControlExs.QQButton();
            this.BlackPicTextBox = new ControlExs.QQTextBox();
            this.BlackStartButton = new ControlExs.QQButton();
            this.BlackOutputButton = new ControlExs.QQButton();
            this.BlackVideoButton = new ControlExs.QQButton();
            this.BlackOutputTextBox = new ControlExs.QQTextBox();
            this.BlackVideoTextBox = new ControlExs.QQTextBox();
            this.SetupTabPage = new System.Windows.Forms.TabPage();
            this.qqButton1 = new ControlExs.QQButton();
            this.x264PriorityComboBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.languageComboBox = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btnMP4 = new ControlExs.QQButton();
            this.btnflv = new ControlExs.QQButton();
            this.DeleteLogButton = new ControlExs.QQButton();
            this.ViewLogButton = new ControlExs.QQButton();
            this.groupBox10.SuspendLayout();
            this.MediaInfoTab.SuspendLayout();
            this.AVSTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrimEndNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrimStartNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelsNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders4NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders3NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders2NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpenNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders1NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AVSHeightNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AVSWidthNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakContrastNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakBrightnessNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakSaturationNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakChromaNumericUpDown)).BeginInit();
            this.ExtractTab.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.MuxTab.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabNeroAAC.SuspendLayout();
            this.NeroAACGroupBox.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numq)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OnePicCRFNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AudioOnePicFPSNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AudioOnePicAudioBitrateNum)).BeginInit();
            this.VideoTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.x264FramesNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x264SeekNumericUpDown)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numheight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numwidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numcrf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numrate)).BeginInit();
            this.HelpTab.SuspendLayout();
            this.AudioTab.SuspendLayout();
            this.MiscTab.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BlackBitrateNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackCRFNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackFPSNum)).BeginInit();
            this.SetupTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 9000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtvideo4);
            this.groupBox10.Controls.Add(this.btnvideo4);
            this.groupBox10.Controls.Add(this.btnout5);
            this.groupBox10.Controls.Add(this.btnClip);
            this.groupBox10.Controls.Add(this.txtout5);
            this.groupBox10.Controls.Add(this.maske);
            this.groupBox10.Controls.Add(this.label13);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.maskb);
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // txtvideo4
            // 
            this.txtvideo4.AllowDrop = true;
            this.txtvideo4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo4.EmptyTextTip = null;
            this.txtvideo4.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo4, "txtvideo4");
            this.txtvideo4.Name = "txtvideo4";
            this.txtvideo4.TextChanged += new System.EventHandler(this.txtvideo4_TextChanged);
            this.txtvideo4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtvideo4_MouseDoubleClick);
            // 
            // btnvideo4
            // 
            resources.ApplyResources(this.btnvideo4, "btnvideo4");
            this.btnvideo4.Name = "btnvideo4";
            this.btnvideo4.UseVisualStyleBackColor = true;
            this.btnvideo4.Click += new System.EventHandler(this.btnvideo4_Click);
            // 
            // btnout5
            // 
            resources.ApplyResources(this.btnout5, "btnout5");
            this.btnout5.Name = "btnout5";
            this.btnout5.UseVisualStyleBackColor = true;
            this.btnout5.Click += new System.EventHandler(this.btnout5_Click);
            // 
            // btnClip
            // 
            resources.ApplyResources(this.btnClip, "btnClip");
            this.btnClip.Name = "btnClip";
            this.btnClip.UseVisualStyleBackColor = true;
            this.btnClip.Click += new System.EventHandler(this.btnClip_Click);
            // 
            // txtout5
            // 
            this.txtout5.AllowDrop = true;
            this.txtout5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtout5.EmptyTextTip = null;
            this.txtout5.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtout5, "txtout5");
            this.txtout5.Name = "txtout5";
            this.txtout5.TextChanged += new System.EventHandler(this.txtout5_TextChanged);
            this.txtout5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtout5_MouseDoubleClick);
            // 
            // maske
            // 
            resources.ApplyResources(this.maske, "maske");
            this.maske.Name = "maske";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // maskb
            // 
            resources.ApplyResources(this.maskb, "maskb");
            this.maskb.Name = "maskb";
            // 
            // btnout4
            // 
            resources.ApplyResources(this.btnout4, "btnout4");
            this.btnout4.Name = "btnout4";
            this.btnout4.UseVisualStyleBackColor = true;
            this.btnout4.Click += new System.EventHandler(this.btnout4_Click);
            // 
            // cbDelTmp
            // 
            resources.ApplyResources(this.cbDelTmp, "cbDelTmp");
            this.cbDelTmp.BackColor = System.Drawing.Color.Transparent;
            this.cbDelTmp.Name = "cbDelTmp";
            this.cbDelTmp.UseVisualStyleBackColor = true;
            // 
            // MediaInfoTab
            // 
            this.MediaInfoTab.Controls.Add(this.btnMIopen);
            this.MediaInfoTab.Controls.Add(this.btnMIplay);
            this.MediaInfoTab.Controls.Add(this.btnMIcopy);
            this.MediaInfoTab.Controls.Add(this.txtMI);
            resources.ApplyResources(this.MediaInfoTab, "MediaInfoTab");
            this.MediaInfoTab.Name = "MediaInfoTab";
            this.MediaInfoTab.UseVisualStyleBackColor = true;
            // 
            // btnMIopen
            // 
            resources.ApplyResources(this.btnMIopen, "btnMIopen");
            this.btnMIopen.Name = "btnMIopen";
            this.btnMIopen.UseVisualStyleBackColor = true;
            this.btnMIopen.Click += new System.EventHandler(this.btnMIopen_Click);
            // 
            // btnMIplay
            // 
            resources.ApplyResources(this.btnMIplay, "btnMIplay");
            this.btnMIplay.Name = "btnMIplay";
            this.btnMIplay.UseVisualStyleBackColor = true;
            this.btnMIplay.Click += new System.EventHandler(this.btnMIplay_Click);
            // 
            // btnMIcopy
            // 
            resources.ApplyResources(this.btnMIcopy, "btnMIcopy");
            this.btnMIcopy.Name = "btnMIcopy";
            this.btnMIcopy.UseVisualStyleBackColor = true;
            this.btnMIcopy.Click += new System.EventHandler(this.btnMIcopy_Click);
            // 
            // txtMI
            // 
            this.txtMI.AllowDrop = true;
            this.txtMI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.txtMI, "txtMI");
            this.txtMI.Name = "txtMI";
            this.txtMI.TextChanged += new System.EventHandler(this.txtMI_TextChanged);
            this.txtMI.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtMI_DragDrop);
            this.txtMI.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtMI_DragEnter);
            // 
            // AVSTab
            // 
            this.AVSTab.Controls.Add(this.AVSSaveButton);
            this.AVSTab.Controls.Add(this.AVSSubCheckBox);
            this.AVSTab.Controls.Add(this.label25);
            this.AVSTab.Controls.Add(this.AVSCropTextBox);
            this.AVSTab.Controls.Add(this.label30);
            this.AVSTab.Controls.Add(this.label29);
            this.AVSTab.Controls.Add(this.TrimEndNumericUpDown);
            this.AVSTab.Controls.Add(this.TrimStartNumericUpDown);
            this.AVSTab.Controls.Add(this.LevelsNumericUpDown);
            this.AVSTab.Controls.Add(this.label24);
            this.AVSTab.Controls.Add(this.label23);
            this.AVSTab.Controls.Add(this.label22);
            this.AVSTab.Controls.Add(this.label21);
            this.AVSTab.Controls.Add(this.AddBorders4NumericUpDown);
            this.AVSTab.Controls.Add(this.AddBorders3NumericUpDown);
            this.AVSTab.Controls.Add(this.AddBorders2NumericUpDown);
            this.AVSTab.Controls.Add(this.SharpenNumericUpDown);
            this.AVSTab.Controls.Add(this.AddBorders1NumericUpDown);
            this.AVSTab.Controls.Add(this.label19);
            this.AVSTab.Controls.Add(this.label20);
            this.AVSTab.Controls.Add(this.AVSHeightNumericUpDown);
            this.AVSTab.Controls.Add(this.AVSWidthNumericUpDown);
            this.AVSTab.Controls.Add(this.label18);
            this.AVSTab.Controls.Add(this.label10);
            this.AVSTab.Controls.Add(this.label9);
            this.AVSTab.Controls.Add(this.label5);
            this.AVSTab.Controls.Add(this.TweakContrastNumericUpDown);
            this.AVSTab.Controls.Add(this.TweakBrightnessNumericUpDown);
            this.AVSTab.Controls.Add(this.TweakSaturationNumericUpDown);
            this.AVSTab.Controls.Add(this.TweakChromaNumericUpDown);
            this.AVSTab.Controls.Add(this.label2);
            this.AVSTab.Controls.Add(this.txtAVS);
            this.AVSTab.Controls.Add(this.txtvideo9);
            this.AVSTab.Controls.Add(this.txtout9);
            this.AVSTab.Controls.Add(this.txtsub9);
            this.AVSTab.Controls.Add(this.LevelsCheckBox);
            this.AVSTab.Controls.Add(this.CropCheckBox);
            this.AVSTab.Controls.Add(this.TrimCheckBox);
            this.AVSTab.Controls.Add(this.SharpenCheckBox);
            this.AVSTab.Controls.Add(this.AddBordersCheckBox);
            this.AVSTab.Controls.Add(this.LanczosResizeCheckBox);
            this.AVSTab.Controls.Add(this.TweakCheckBox);
            this.AVSTab.Controls.Add(this.UndotCheckBox);
            this.AVSTab.Controls.Add(this.button9);
            this.AVSTab.Controls.Add(this.button6);
            this.AVSTab.Controls.Add(this.btnpreview9);
            this.AVSTab.Controls.Add(this.btnAVSone);
            this.AVSTab.Controls.Add(this.btnAVS9);
            this.AVSTab.Controls.Add(this.btnvideo9);
            this.AVSTab.Controls.Add(this.btnout9);
            this.AVSTab.Controls.Add(this.btnsub9);
            resources.ApplyResources(this.AVSTab, "AVSTab");
            this.AVSTab.Name = "AVSTab";
            this.AVSTab.UseVisualStyleBackColor = true;
            this.AVSTab.Click += new System.EventHandler(this.txtAVScreate_Click);
            // 
            // AVSSaveButton
            // 
            resources.ApplyResources(this.AVSSaveButton, "AVSSaveButton");
            this.AVSSaveButton.Name = "AVSSaveButton";
            this.AVSSaveButton.UseVisualStyleBackColor = true;
            this.AVSSaveButton.Click += new System.EventHandler(this.AVSSaveButton_Click);
            // 
            // AVSSubCheckBox
            // 
            resources.ApplyResources(this.AVSSubCheckBox, "AVSSubCheckBox");
            this.AVSSubCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.AVSSubCheckBox.Checked = true;
            this.AVSSubCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AVSSubCheckBox.Name = "AVSSubCheckBox";
            this.AVSSubCheckBox.UseVisualStyleBackColor = false;
            this.AVSSubCheckBox.CheckedChanged += new System.EventHandler(this.AVSSubCheckBox_CheckedChanged);
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // AVSCropTextBox
            // 
            this.AVSCropTextBox.AllowDrop = true;
            this.AVSCropTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AVSCropTextBox.EmptyTextTip = null;
            this.AVSCropTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.AVSCropTextBox, "AVSCropTextBox");
            this.AVSCropTextBox.Name = "AVSCropTextBox";
            this.AVSCropTextBox.TextChanged += new System.EventHandler(this.AVSCropTextBox_TextChanged);
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            // 
            // TrimEndNumericUpDown
            // 
            resources.ApplyResources(this.TrimEndNumericUpDown, "TrimEndNumericUpDown");
            this.TrimEndNumericUpDown.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.TrimEndNumericUpDown.Name = "TrimEndNumericUpDown";
            this.TrimEndNumericUpDown.Value = new decimal(new int[] {
            1440,
            0,
            0,
            0});
            this.TrimEndNumericUpDown.ValueChanged += new System.EventHandler(this.TrimEndNumericUpDown_ValueChanged);
            // 
            // TrimStartNumericUpDown
            // 
            resources.ApplyResources(this.TrimStartNumericUpDown, "TrimStartNumericUpDown");
            this.TrimStartNumericUpDown.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.TrimStartNumericUpDown.Name = "TrimStartNumericUpDown";
            this.TrimStartNumericUpDown.ValueChanged += new System.EventHandler(this.TrimStartNumericUpDown_ValueChanged);
            // 
            // LevelsNumericUpDown
            // 
            this.LevelsNumericUpDown.DecimalPlaces = 1;
            this.LevelsNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.LevelsNumericUpDown, "LevelsNumericUpDown");
            this.LevelsNumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.LevelsNumericUpDown.Name = "LevelsNumericUpDown";
            this.LevelsNumericUpDown.Value = new decimal(new int[] {
            12,
            0,
            0,
            65536});
            this.LevelsNumericUpDown.ValueChanged += new System.EventHandler(this.LevelsNumericUpDown_ValueChanged);
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // AddBorders4NumericUpDown
            // 
            resources.ApplyResources(this.AddBorders4NumericUpDown, "AddBorders4NumericUpDown");
            this.AddBorders4NumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AddBorders4NumericUpDown.Name = "AddBorders4NumericUpDown";
            this.AddBorders4NumericUpDown.ValueChanged += new System.EventHandler(this.AddBorders4NumericUpDown_ValueChanged);
            // 
            // AddBorders3NumericUpDown
            // 
            resources.ApplyResources(this.AddBorders3NumericUpDown, "AddBorders3NumericUpDown");
            this.AddBorders3NumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AddBorders3NumericUpDown.Name = "AddBorders3NumericUpDown";
            this.AddBorders3NumericUpDown.ValueChanged += new System.EventHandler(this.AddBorders3NumericUpDown_ValueChanged);
            // 
            // AddBorders2NumericUpDown
            // 
            resources.ApplyResources(this.AddBorders2NumericUpDown, "AddBorders2NumericUpDown");
            this.AddBorders2NumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AddBorders2NumericUpDown.Name = "AddBorders2NumericUpDown";
            this.AddBorders2NumericUpDown.ValueChanged += new System.EventHandler(this.AddBorders2NumericUpDown_ValueChanged);
            // 
            // SharpenNumericUpDown
            // 
            this.SharpenNumericUpDown.DecimalPlaces = 1;
            this.SharpenNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.SharpenNumericUpDown, "SharpenNumericUpDown");
            this.SharpenNumericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.SharpenNumericUpDown.Name = "SharpenNumericUpDown";
            this.SharpenNumericUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.SharpenNumericUpDown.ValueChanged += new System.EventHandler(this.SharpenNumericUpDown_ValueChanged);
            // 
            // AddBorders1NumericUpDown
            // 
            resources.ApplyResources(this.AddBorders1NumericUpDown, "AddBorders1NumericUpDown");
            this.AddBorders1NumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AddBorders1NumericUpDown.Name = "AddBorders1NumericUpDown";
            this.AddBorders1NumericUpDown.ValueChanged += new System.EventHandler(this.AddBorders1NumericUpDown_ValueChanged);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // AVSHeightNumericUpDown
            // 
            resources.ApplyResources(this.AVSHeightNumericUpDown, "AVSHeightNumericUpDown");
            this.AVSHeightNumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AVSHeightNumericUpDown.Name = "AVSHeightNumericUpDown";
            this.AVSHeightNumericUpDown.Value = new decimal(new int[] {
            720,
            0,
            0,
            0});
            this.AVSHeightNumericUpDown.ValueChanged += new System.EventHandler(this.AVSHeightNumericUpDown_ValueChanged);
            // 
            // AVSWidthNumericUpDown
            // 
            resources.ApplyResources(this.AVSWidthNumericUpDown, "AVSWidthNumericUpDown");
            this.AVSWidthNumericUpDown.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.AVSWidthNumericUpDown.Name = "AVSWidthNumericUpDown";
            this.AVSWidthNumericUpDown.Value = new decimal(new int[] {
            1280,
            0,
            0,
            0});
            this.AVSWidthNumericUpDown.ValueChanged += new System.EventHandler(this.AVSWidthNumericUpDown_ValueChanged);
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // TweakContrastNumericUpDown
            // 
            this.TweakContrastNumericUpDown.DecimalPlaces = 1;
            this.TweakContrastNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.TweakContrastNumericUpDown, "TweakContrastNumericUpDown");
            this.TweakContrastNumericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.TweakContrastNumericUpDown.Name = "TweakContrastNumericUpDown";
            this.TweakContrastNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.TweakContrastNumericUpDown.ValueChanged += new System.EventHandler(this.TweakContrastNumericUpDown_ValueChanged);
            // 
            // TweakBrightnessNumericUpDown
            // 
            this.TweakBrightnessNumericUpDown.DecimalPlaces = 1;
            resources.ApplyResources(this.TweakBrightnessNumericUpDown, "TweakBrightnessNumericUpDown");
            this.TweakBrightnessNumericUpDown.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.TweakBrightnessNumericUpDown.Minimum = new decimal(new int[] {
            255,
            0,
            0,
            -2147483648});
            this.TweakBrightnessNumericUpDown.Name = "TweakBrightnessNumericUpDown";
            this.TweakBrightnessNumericUpDown.ValueChanged += new System.EventHandler(this.TweakBrightnessNumericUpDown_ValueChanged);
            // 
            // TweakSaturationNumericUpDown
            // 
            this.TweakSaturationNumericUpDown.DecimalPlaces = 1;
            this.TweakSaturationNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.TweakSaturationNumericUpDown, "TweakSaturationNumericUpDown");
            this.TweakSaturationNumericUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.TweakSaturationNumericUpDown.Name = "TweakSaturationNumericUpDown";
            this.TweakSaturationNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.TweakSaturationNumericUpDown.ValueChanged += new System.EventHandler(this.TweakSaturationNumericUpDown_ValueChanged);
            // 
            // TweakChromaNumericUpDown
            // 
            this.TweakChromaNumericUpDown.DecimalPlaces = 1;
            this.TweakChromaNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.TweakChromaNumericUpDown, "TweakChromaNumericUpDown");
            this.TweakChromaNumericUpDown.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.TweakChromaNumericUpDown.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.TweakChromaNumericUpDown.Name = "TweakChromaNumericUpDown";
            this.TweakChromaNumericUpDown.ValueChanged += new System.EventHandler(this.TweakChromaNumericUpDown_ValueChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // txtAVS
            // 
            this.txtAVS.AllowDrop = true;
            this.txtAVS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAVS.EmptyTextTip = null;
            this.txtAVS.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtAVS, "txtAVS");
            this.txtAVS.Name = "txtAVS";
            this.txtAVS.TextChanged += new System.EventHandler(this.txtAVS_TextChanged);
            // 
            // txtvideo9
            // 
            this.txtvideo9.AllowDrop = true;
            this.txtvideo9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo9.EmptyTextTip = null;
            this.txtvideo9.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo9, "txtvideo9");
            this.txtvideo9.Name = "txtvideo9";
            this.txtvideo9.TextChanged += new System.EventHandler(this.txtvideo9_TextChanged);
            this.txtvideo9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtvideo9_MouseDoubleClick);
            // 
            // txtout9
            // 
            this.txtout9.AllowDrop = true;
            this.txtout9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtout9.EmptyTextTip = null;
            this.txtout9.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtout9, "txtout9");
            this.txtout9.Name = "txtout9";
            this.txtout9.TextChanged += new System.EventHandler(this.txtout9_TextChanged);
            this.txtout9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtout9_MouseDoubleClick);
            // 
            // txtsub9
            // 
            this.txtsub9.AllowDrop = true;
            this.txtsub9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsub9.EmptyTextTip = null;
            this.txtsub9.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtsub9, "txtsub9");
            this.txtsub9.Name = "txtsub9";
            this.txtsub9.TextChanged += new System.EventHandler(this.txtsub9_TextChanged);
            // 
            // LevelsCheckBox
            // 
            resources.ApplyResources(this.LevelsCheckBox, "LevelsCheckBox");
            this.LevelsCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.LevelsCheckBox.Name = "LevelsCheckBox";
            this.LevelsCheckBox.UseVisualStyleBackColor = false;
            this.LevelsCheckBox.CheckedChanged += new System.EventHandler(this.LevelsCheckBox_CheckedChanged);
            // 
            // CropCheckBox
            // 
            resources.ApplyResources(this.CropCheckBox, "CropCheckBox");
            this.CropCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.CropCheckBox.Name = "CropCheckBox";
            this.CropCheckBox.UseVisualStyleBackColor = false;
            this.CropCheckBox.CheckedChanged += new System.EventHandler(this.CropCheckBox_CheckedChanged);
            // 
            // TrimCheckBox
            // 
            resources.ApplyResources(this.TrimCheckBox, "TrimCheckBox");
            this.TrimCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.TrimCheckBox.Name = "TrimCheckBox";
            this.TrimCheckBox.UseVisualStyleBackColor = false;
            this.TrimCheckBox.CheckedChanged += new System.EventHandler(this.TrimCheckBox_CheckedChanged);
            // 
            // SharpenCheckBox
            // 
            resources.ApplyResources(this.SharpenCheckBox, "SharpenCheckBox");
            this.SharpenCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.SharpenCheckBox.Name = "SharpenCheckBox";
            this.SharpenCheckBox.UseVisualStyleBackColor = false;
            this.SharpenCheckBox.CheckedChanged += new System.EventHandler(this.SharpenCheckBox_CheckedChanged);
            // 
            // AddBordersCheckBox
            // 
            resources.ApplyResources(this.AddBordersCheckBox, "AddBordersCheckBox");
            this.AddBordersCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.AddBordersCheckBox.Name = "AddBordersCheckBox";
            this.AddBordersCheckBox.UseVisualStyleBackColor = false;
            this.AddBordersCheckBox.CheckedChanged += new System.EventHandler(this.AddBordersCheckBox_CheckedChanged);
            // 
            // LanczosResizeCheckBox
            // 
            resources.ApplyResources(this.LanczosResizeCheckBox, "LanczosResizeCheckBox");
            this.LanczosResizeCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.LanczosResizeCheckBox.Name = "LanczosResizeCheckBox";
            this.LanczosResizeCheckBox.UseVisualStyleBackColor = false;
            this.LanczosResizeCheckBox.CheckedChanged += new System.EventHandler(this.LanczosResizeCheckBox_CheckedChanged);
            // 
            // TweakCheckBox
            // 
            resources.ApplyResources(this.TweakCheckBox, "TweakCheckBox");
            this.TweakCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.TweakCheckBox.Name = "TweakCheckBox";
            this.TweakCheckBox.UseVisualStyleBackColor = false;
            this.TweakCheckBox.CheckedChanged += new System.EventHandler(this.TweakCheckBox_CheckedChanged);
            // 
            // UndotCheckBox
            // 
            resources.ApplyResources(this.UndotCheckBox, "UndotCheckBox");
            this.UndotCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.UndotCheckBox.Name = "UndotCheckBox";
            this.UndotCheckBox.UseVisualStyleBackColor = false;
            this.UndotCheckBox.CheckedChanged += new System.EventHandler(this.UndotCheckBox_CheckedChanged);
            // 
            // button9
            // 
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_2);
            // 
            // btnpreview9
            // 
            resources.ApplyResources(this.btnpreview9, "btnpreview9");
            this.btnpreview9.Name = "btnpreview9";
            this.btnpreview9.UseVisualStyleBackColor = true;
            this.btnpreview9.Click += new System.EventHandler(this.btnpreview9_Click);
            // 
            // btnAVSone
            // 
            resources.ApplyResources(this.btnAVSone, "btnAVSone");
            this.btnAVSone.Name = "btnAVSone";
            this.btnAVSone.UseVisualStyleBackColor = true;
            this.btnAVSone.Click += new System.EventHandler(this.btnAVSone_Click);
            // 
            // btnAVS9
            // 
            resources.ApplyResources(this.btnAVS9, "btnAVS9");
            this.btnAVS9.Name = "btnAVS9";
            this.btnAVS9.UseVisualStyleBackColor = true;
            this.btnAVS9.Click += new System.EventHandler(this.btnAVS9_Click);
            // 
            // btnvideo9
            // 
            resources.ApplyResources(this.btnvideo9, "btnvideo9");
            this.btnvideo9.Name = "btnvideo9";
            this.btnvideo9.UseVisualStyleBackColor = true;
            this.btnvideo9.Click += new System.EventHandler(this.btnvideo9_Click);
            // 
            // btnout9
            // 
            resources.ApplyResources(this.btnout9, "btnout9");
            this.btnout9.Name = "btnout9";
            this.btnout9.UseVisualStyleBackColor = true;
            this.btnout9.Click += new System.EventHandler(this.btnout9_Click);
            // 
            // btnsub9
            // 
            resources.ApplyResources(this.btnsub9, "btnsub9");
            this.btnsub9.Name = "btnsub9";
            this.btnsub9.UseVisualStyleBackColor = true;
            this.btnsub9.Click += new System.EventHandler(this.btnsub9_Click);
            // 
            // ExtractTab
            // 
            this.ExtractTab.AllowDrop = true;
            this.ExtractTab.Controls.Add(this.groupBox7);
            this.ExtractTab.Controls.Add(this.groupBox6);
            this.ExtractTab.Controls.Add(this.groupBox5);
            resources.ApplyResources(this.ExtractTab, "ExtractTab");
            this.ExtractTab.Name = "ExtractTab";
            this.ExtractTab.UseVisualStyleBackColor = true;
            this.ExtractTab.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.MkvExtract4Button);
            this.groupBox7.Controls.Add(this.MkvExtract3Button);
            this.groupBox7.Controls.Add(this.MkvExtract2Button);
            this.groupBox7.Controls.Add(this.MkvExtract1Button);
            this.groupBox7.Controls.Add(this.btnextract7);
            this.groupBox7.Controls.Add(this.btnvideo7);
            this.groupBox7.Controls.Add(this.txtvideo6);
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // MkvExtract4Button
            // 
            resources.ApplyResources(this.MkvExtract4Button, "MkvExtract4Button");
            this.MkvExtract4Button.Name = "MkvExtract4Button";
            this.MkvExtract4Button.UseVisualStyleBackColor = true;
            this.MkvExtract4Button.Click += new System.EventHandler(this.btnextract7_Click);
            // 
            // MkvExtract3Button
            // 
            resources.ApplyResources(this.MkvExtract3Button, "MkvExtract3Button");
            this.MkvExtract3Button.Name = "MkvExtract3Button";
            this.MkvExtract3Button.UseVisualStyleBackColor = true;
            this.MkvExtract3Button.Click += new System.EventHandler(this.btnextract7_Click);
            // 
            // MkvExtract2Button
            // 
            resources.ApplyResources(this.MkvExtract2Button, "MkvExtract2Button");
            this.MkvExtract2Button.Name = "MkvExtract2Button";
            this.MkvExtract2Button.UseVisualStyleBackColor = true;
            this.MkvExtract2Button.Click += new System.EventHandler(this.btnextract7_Click);
            // 
            // MkvExtract1Button
            // 
            resources.ApplyResources(this.MkvExtract1Button, "MkvExtract1Button");
            this.MkvExtract1Button.Name = "MkvExtract1Button";
            this.MkvExtract1Button.UseVisualStyleBackColor = true;
            this.MkvExtract1Button.Click += new System.EventHandler(this.btnextract7_Click);
            // 
            // btnextract7
            // 
            resources.ApplyResources(this.btnextract7, "btnextract7");
            this.btnextract7.Name = "btnextract7";
            this.btnextract7.UseVisualStyleBackColor = true;
            this.btnextract7.Click += new System.EventHandler(this.btnextract7_Click);
            // 
            // btnvideo7
            // 
            resources.ApplyResources(this.btnvideo7, "btnvideo7");
            this.btnvideo7.Name = "btnvideo7";
            this.btnvideo7.UseVisualStyleBackColor = true;
            this.btnvideo7.Click += new System.EventHandler(this.btnvideo7_Click);
            // 
            // txtvideo6
            // 
            this.txtvideo6.AllowDrop = true;
            this.txtvideo6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo6.EmptyTextTip = "";
            this.txtvideo6.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo6, "txtvideo6");
            this.txtvideo6.Name = "txtvideo6";
            this.txtvideo6.TextChanged += new System.EventHandler(this.txtvideo6_TextChanged_1);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnvextract8);
            this.groupBox6.Controls.Add(this.btnvideo8);
            this.groupBox6.Controls.Add(this.txtvideo8);
            this.groupBox6.Controls.Add(this.btnaextract8);
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // btnvextract8
            // 
            resources.ApplyResources(this.btnvextract8, "btnvextract8");
            this.btnvextract8.Name = "btnvextract8";
            this.btnvextract8.UseVisualStyleBackColor = true;
            this.btnvextract8.Click += new System.EventHandler(this.btnvextract8_Click);
            // 
            // btnvideo8
            // 
            resources.ApplyResources(this.btnvideo8, "btnvideo8");
            this.btnvideo8.Name = "btnvideo8";
            this.btnvideo8.UseVisualStyleBackColor = true;
            this.btnvideo8.Click += new System.EventHandler(this.btnvideo8_Click);
            // 
            // txtvideo8
            // 
            this.txtvideo8.AllowDrop = true;
            this.txtvideo8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo8.EmptyTextTip = "";
            this.txtvideo8.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo8, "txtvideo8");
            this.txtvideo8.Name = "txtvideo8";
            this.txtvideo8.TextChanged += new System.EventHandler(this.txtvideo8_TextChanged);
            this.txtvideo8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtvideo8_MouseDoubleClick);
            // 
            // btnaextract8
            // 
            resources.ApplyResources(this.btnaextract8, "btnaextract8");
            this.btnaextract8.Name = "btnaextract8";
            this.btnaextract8.UseVisualStyleBackColor = true;
            this.btnaextract8.Click += new System.EventHandler(this.btnaextract8_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ExtractMP4TextBox);
            this.groupBox5.Controls.Add(this.btnaextract3);
            this.groupBox5.Controls.Add(this.ExtractMP4Button);
            this.groupBox5.Controls.Add(this.btnvextract);
            this.groupBox5.Controls.Add(this.btnaextract);
            this.groupBox5.Controls.Add(this.btnaextract2);
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // ExtractMP4TextBox
            // 
            this.ExtractMP4TextBox.AllowDrop = true;
            this.ExtractMP4TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ExtractMP4TextBox.EmptyTextTip = "";
            this.ExtractMP4TextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.ExtractMP4TextBox, "ExtractMP4TextBox");
            this.ExtractMP4TextBox.Name = "ExtractMP4TextBox";
            this.ExtractMP4TextBox.TextChanged += new System.EventHandler(this.ExtractMP4TextBox_TextChanged);
            // 
            // btnaextract3
            // 
            resources.ApplyResources(this.btnaextract3, "btnaextract3");
            this.btnaextract3.Name = "btnaextract3";
            this.btnaextract3.UseVisualStyleBackColor = true;
            this.btnaextract3.Click += new System.EventHandler(this.btnaextract3_Click);
            // 
            // ExtractMP4Button
            // 
            resources.ApplyResources(this.ExtractMP4Button, "ExtractMP4Button");
            this.ExtractMP4Button.Name = "ExtractMP4Button";
            this.ExtractMP4Button.UseVisualStyleBackColor = true;
            this.ExtractMP4Button.Click += new System.EventHandler(this.ExtractMP4Button_Click);
            // 
            // btnvextract
            // 
            resources.ApplyResources(this.btnvextract, "btnvextract");
            this.btnvextract.Name = "btnvextract";
            this.btnvextract.UseVisualStyleBackColor = true;
            this.btnvextract.Click += new System.EventHandler(this.btnvextract_Click);
            // 
            // btnaextract
            // 
            resources.ApplyResources(this.btnaextract, "btnaextract");
            this.btnaextract.Name = "btnaextract";
            this.btnaextract.UseVisualStyleBackColor = true;
            this.btnaextract.Click += new System.EventHandler(this.btnaextract_Click);
            // 
            // btnaextract2
            // 
            resources.ApplyResources(this.btnaextract2, "btnaextract2");
            this.btnaextract2.Name = "btnaextract2";
            this.btnaextract2.UseVisualStyleBackColor = true;
            this.btnaextract2.Click += new System.EventHandler(this.btnaextract2_Click);
            // 
            // MuxTab
            // 
            this.MuxTab.Controls.Add(this.groupBox4);
            this.MuxTab.Controls.Add(this.groupBox3);
            this.MuxTab.Controls.Add(this.groupBox8);
            resources.ApplyResources(this.MuxTab, "MuxTab");
            this.MuxTab.Name = "MuxTab";
            this.MuxTab.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lbffmpeg);
            this.groupBox4.Controls.Add(this.btnffmpegAdd);
            this.groupBox4.Controls.Add(this.btnffmpegClear);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.btnffmpegDel);
            this.groupBox4.Controls.Add(this.btnBatchMP4);
            this.groupBox4.Controls.Add(this.btnBatchFLV);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // lbffmpeg
            // 
            this.lbffmpeg.AllowDrop = true;
            this.lbffmpeg.FormattingEnabled = true;
            resources.ApplyResources(this.lbffmpeg, "lbffmpeg");
            this.lbffmpeg.Name = "lbffmpeg";
            this.lbffmpeg.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbffmpeg_DragDrop);
            this.lbffmpeg.DragOver += new System.Windows.Forms.DragEventHandler(this.lbffmpeg_DragOver);
            this.lbffmpeg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbffmpeg_MouseDown);
            // 
            // btnffmpegAdd
            // 
            resources.ApplyResources(this.btnffmpegAdd, "btnffmpegAdd");
            this.btnffmpegAdd.Name = "btnffmpegAdd";
            this.btnffmpegAdd.UseVisualStyleBackColor = true;
            this.btnffmpegAdd.Click += new System.EventHandler(this.btnffmpegAdd_Click);
            // 
            // btnffmpegClear
            // 
            resources.ApplyResources(this.btnffmpegClear, "btnffmpegClear");
            this.btnffmpegClear.Name = "btnffmpegClear";
            this.btnffmpegClear.UseVisualStyleBackColor = true;
            this.btnffmpegClear.Click += new System.EventHandler(this.btnffmpegClear_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // btnffmpegDel
            // 
            resources.ApplyResources(this.btnffmpegDel, "btnffmpegDel");
            this.btnffmpegDel.Name = "btnffmpegDel";
            this.btnffmpegDel.UseVisualStyleBackColor = true;
            this.btnffmpegDel.Click += new System.EventHandler(this.btnffmpegDel_Click);
            // 
            // btnBatchMP4
            // 
            resources.ApplyResources(this.btnBatchMP4, "btnBatchMP4");
            this.btnBatchMP4.Name = "btnBatchMP4";
            this.btnBatchMP4.UseVisualStyleBackColor = true;
            this.btnBatchMP4.Click += new System.EventHandler(this.btnBatchMP4_Click);
            // 
            // btnBatchFLV
            // 
            resources.ApplyResources(this.btnBatchFLV, "btnBatchFLV");
            this.btnBatchFLV.Name = "btnBatchFLV";
            this.btnBatchFLV.UseVisualStyleBackColor = true;
            this.btnBatchFLV.Click += new System.EventHandler(this.btnBatchFLV_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.MuxReplaceAudioButton);
            this.groupBox3.Controls.Add(this.txtvideo);
            this.groupBox3.Controls.Add(this.btnvideo);
            this.groupBox3.Controls.Add(this.btnmux);
            this.groupBox3.Controls.Add(this.cbFPS);
            this.groupBox3.Controls.Add(this.btnaudio);
            this.groupBox3.Controls.Add(this.btnout);
            this.groupBox3.Controls.Add(this.txtaudio);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtout);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // MuxReplaceAudioButton
            // 
            resources.ApplyResources(this.MuxReplaceAudioButton, "MuxReplaceAudioButton");
            this.MuxReplaceAudioButton.Name = "MuxReplaceAudioButton";
            this.MuxReplaceAudioButton.UseVisualStyleBackColor = true;
            this.MuxReplaceAudioButton.Click += new System.EventHandler(this.MuxReplaceAudioButton_Click);
            // 
            // txtvideo
            // 
            this.txtvideo.AllowDrop = true;
            this.txtvideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo.EmptyTextTip = "";
            this.txtvideo.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo, "txtvideo");
            this.txtvideo.Name = "txtvideo";
            this.txtvideo.TextChanged += new System.EventHandler(this.txtvideo_TextChanged);
            this.txtvideo.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtvideo_MouseDoubleClick);
            // 
            // btnvideo
            // 
            resources.ApplyResources(this.btnvideo, "btnvideo");
            this.btnvideo.Name = "btnvideo";
            this.btnvideo.UseVisualStyleBackColor = true;
            this.btnvideo.Click += new System.EventHandler(this.btnvideo_Click);
            // 
            // btnmux
            // 
            resources.ApplyResources(this.btnmux, "btnmux");
            this.btnmux.Name = "btnmux";
            this.btnmux.UseVisualStyleBackColor = true;
            this.btnmux.Click += new System.EventHandler(this.btnmux_Click);
            // 
            // cbFPS
            // 
            this.cbFPS.FormattingEnabled = true;
            this.cbFPS.Items.AddRange(new object[] {
            resources.GetString("cbFPS.Items"),
            resources.GetString("cbFPS.Items1"),
            resources.GetString("cbFPS.Items2"),
            resources.GetString("cbFPS.Items3"),
            resources.GetString("cbFPS.Items4"),
            resources.GetString("cbFPS.Items5"),
            resources.GetString("cbFPS.Items6"),
            resources.GetString("cbFPS.Items7"),
            resources.GetString("cbFPS.Items8")});
            resources.ApplyResources(this.cbFPS, "cbFPS");
            this.cbFPS.Name = "cbFPS";
            this.cbFPS.SelectedIndexChanged += new System.EventHandler(this.cbFPS_SelectedIndexChanged);
            // 
            // btnaudio
            // 
            resources.ApplyResources(this.btnaudio, "btnaudio");
            this.btnaudio.Name = "btnaudio";
            this.btnaudio.UseVisualStyleBackColor = true;
            this.btnaudio.Click += new System.EventHandler(this.btnaudio_Click);
            // 
            // btnout
            // 
            resources.ApplyResources(this.btnout, "btnout");
            this.btnout.Name = "btnout";
            this.btnout.UseVisualStyleBackColor = true;
            this.btnout.Click += new System.EventHandler(this.btnout_Click);
            // 
            // txtaudio
            // 
            this.txtaudio.AllowDrop = true;
            this.txtaudio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtaudio.EmptyTextTip = null;
            this.txtaudio.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtaudio, "txtaudio");
            this.txtaudio.Name = "txtaudio";
            this.txtaudio.TextChanged += new System.EventHandler(this.txtaudio_TextChanged);
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // txtout
            // 
            this.txtout.AllowDrop = true;
            this.txtout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtout.EmptyTextTip = null;
            this.txtout.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtout, "txtout");
            this.txtout.Name = "txtout";
            this.txtout.TextChanged += new System.EventHandler(this.txtout_TextChanged);
            this.txtout.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtout_MouseDoubleClick);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtvideo5);
            this.groupBox8.Controls.Add(this.button4);
            this.groupBox8.Controls.Add(this.txtsub);
            this.groupBox8.Controls.Add(this.button3);
            this.groupBox8.Controls.Add(this.txtaudio3);
            this.groupBox8.Controls.Add(this.button5);
            this.groupBox8.Controls.Add(this.txtout6);
            this.groupBox8.Controls.Add(this.button2);
            this.groupBox8.Controls.Add(this.button7);
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // txtvideo5
            // 
            this.txtvideo5.AllowDrop = true;
            this.txtvideo5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtvideo5.EmptyTextTip = null;
            this.txtvideo5.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtvideo5, "txtvideo5");
            this.txtvideo5.Name = "txtvideo5";
            this.txtvideo5.TextChanged += new System.EventHandler(this.txtvideo5_TextChanged);
            this.txtvideo5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtvideo5_MouseDoubleClick);
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // txtsub
            // 
            this.txtsub.AllowDrop = true;
            this.txtsub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsub.EmptyTextTip = null;
            this.txtsub.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtsub, "txtsub");
            this.txtsub.Name = "txtsub";
            this.txtsub.TextChanged += new System.EventHandler(this.txtsub_TextChanged);
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // txtaudio3
            // 
            this.txtaudio3.AllowDrop = true;
            this.txtaudio3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtaudio3.EmptyTextTip = "";
            this.txtaudio3.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtaudio3, "txtaudio3");
            this.txtaudio3.Name = "txtaudio3";
            this.txtaudio3.TextChanged += new System.EventHandler(this.txtaudio3_TextChanged);
            this.txtaudio3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtaudio3_MouseDoubleClick);
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // txtout6
            // 
            this.txtout6.AllowDrop = true;
            this.txtout6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtout6.EmptyTextTip = null;
            this.txtout6.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtout6, "txtout6");
            this.txtout6.Name = "txtout6";
            this.txtout6.TextChanged += new System.EventHandler(this.txtout6_TextChanged_1);
            this.txtout6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtout6_MouseDoubleClick);
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // tabNeroAAC
            // 
            this.tabNeroAAC.AllowDrop = true;
            this.tabNeroAAC.Controls.Add(this.NeroAACGroupBox);
            this.tabNeroAAC.Controls.Add(this.groupBox2);
            resources.ApplyResources(this.tabNeroAAC, "tabNeroAAC");
            this.tabNeroAAC.Name = "tabNeroAAC";
            this.tabNeroAAC.UseVisualStyleBackColor = true;
            // 
            // NeroAACGroupBox
            // 
            this.NeroAACGroupBox.Controls.Add(this.label7);
            this.NeroAACGroupBox.Controls.Add(this.AudioEncoderComboBox);
            this.NeroAACGroupBox.Controls.Add(this.txtaudio2);
            this.NeroAACGroupBox.Controls.Add(this.panel2);
            this.NeroAACGroupBox.Controls.Add(this.txtout3);
            this.NeroAACGroupBox.Controls.Add(this.cbwavtemp);
            this.NeroAACGroupBox.Controls.Add(this.btnaudio2);
            this.NeroAACGroupBox.Controls.Add(this.lbaackbps);
            this.NeroAACGroupBox.Controls.Add(this.btnout3);
            this.NeroAACGroupBox.Controls.Add(this.lbaacrate);
            this.NeroAACGroupBox.Controls.Add(this.btnaac);
            this.NeroAACGroupBox.Controls.Add(this.numq);
            this.NeroAACGroupBox.Controls.Add(this.txtNeroaac);
            resources.ApplyResources(this.NeroAACGroupBox, "NeroAACGroupBox");
            this.NeroAACGroupBox.Name = "NeroAACGroupBox";
            this.NeroAACGroupBox.TabStop = false;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // AudioEncoderComboBox
            // 
            this.AudioEncoderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AudioEncoderComboBox.FormattingEnabled = true;
            this.AudioEncoderComboBox.Items.AddRange(new object[] {
            resources.GetString("AudioEncoderComboBox.Items"),
            resources.GetString("AudioEncoderComboBox.Items1"),
            resources.GetString("AudioEncoderComboBox.Items2")});
            resources.ApplyResources(this.AudioEncoderComboBox, "AudioEncoderComboBox");
            this.AudioEncoderComboBox.Name = "AudioEncoderComboBox";
            this.AudioEncoderComboBox.SelectedIndexChanged += new System.EventHandler(this.AudioEncoderComboBox_SelectedIndexChanged);
            // 
            // txtaudio2
            // 
            this.txtaudio2.AllowDrop = true;
            this.txtaudio2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtaudio2.EmptyTextTip = null;
            this.txtaudio2.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtaudio2, "txtaudio2");
            this.txtaudio2.Name = "txtaudio2";
            this.txtaudio2.TextChanged += new System.EventHandler(this.txtaudio2_TextChanged);
            this.txtaudio2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtaudio2_MouseDoubleClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.AudioBitrateRadioButton);
            this.panel2.Controls.Add(this.AudioCustomizeRadioButton);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // AudioBitrateRadioButton
            // 
            this.AudioBitrateRadioButton.BackColor = System.Drawing.Color.Transparent;
            this.AudioBitrateRadioButton.Checked = true;
            resources.ApplyResources(this.AudioBitrateRadioButton, "AudioBitrateRadioButton");
            this.AudioBitrateRadioButton.Name = "AudioBitrateRadioButton";
            this.AudioBitrateRadioButton.TabStop = true;
            this.AudioBitrateRadioButton.UseVisualStyleBackColor = true;
            this.AudioBitrateRadioButton.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // AudioCustomizeRadioButton
            // 
            this.AudioCustomizeRadioButton.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.AudioCustomizeRadioButton, "AudioCustomizeRadioButton");
            this.AudioCustomizeRadioButton.Name = "AudioCustomizeRadioButton";
            this.AudioCustomizeRadioButton.UseVisualStyleBackColor = true;
            this.AudioCustomizeRadioButton.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // txtout3
            // 
            this.txtout3.AllowDrop = true;
            this.txtout3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtout3.EmptyTextTip = null;
            this.txtout3.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtout3, "txtout3");
            this.txtout3.Name = "txtout3";
            this.txtout3.TextChanged += new System.EventHandler(this.txtout3_TextChanged);
            this.txtout3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtout3_MouseDoubleClick);
            // 
            // cbwavtemp
            // 
            resources.ApplyResources(this.cbwavtemp, "cbwavtemp");
            this.cbwavtemp.BackColor = System.Drawing.Color.Transparent;
            this.cbwavtemp.Name = "cbwavtemp";
            this.cbwavtemp.UseVisualStyleBackColor = true;
            // 
            // btnaudio2
            // 
            resources.ApplyResources(this.btnaudio2, "btnaudio2");
            this.btnaudio2.Name = "btnaudio2";
            this.btnaudio2.UseVisualStyleBackColor = true;
            this.btnaudio2.Click += new System.EventHandler(this.btnaudio2_Click);
            // 
            // lbaackbps
            // 
            resources.ApplyResources(this.lbaackbps, "lbaackbps");
            this.lbaackbps.Name = "lbaackbps";
            // 
            // btnout3
            // 
            resources.ApplyResources(this.btnout3, "btnout3");
            this.btnout3.Name = "btnout3";
            this.btnout3.UseVisualStyleBackColor = true;
            this.btnout3.Click += new System.EventHandler(this.btnout3_Click);
            // 
            // lbaacrate
            // 
            resources.ApplyResources(this.lbaacrate, "lbaacrate");
            this.lbaacrate.Name = "lbaacrate";
            // 
            // btnaac
            // 
            resources.ApplyResources(this.btnaac, "btnaac");
            this.btnaac.Name = "btnaac";
            this.btnaac.UseVisualStyleBackColor = true;
            this.btnaac.Click += new System.EventHandler(this.btnaac_Click);
            // 
            // numq
            // 
            resources.ApplyResources(this.numq, "numq");
            this.numq.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numq.Name = "numq";
            this.numq.Value = new decimal(new int[] {
            96,
            0,
            0,
            0});
            // 
            // txtNeroaac
            // 
            this.txtNeroaac.AllowDrop = true;
            this.txtNeroaac.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNeroaac.EmptyTextTip = null;
            this.txtNeroaac.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txtNeroaac, "txtNeroaac");
            this.txtNeroaac.Name = "txtNeroaac";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.AudioBatchButton);
            this.groupBox2.Controls.Add(this.AudioListBox);
            this.groupBox2.Controls.Add(this.AudioAddButton);
            this.groupBox2.Controls.Add(this.AudioClearButton);
            this.groupBox2.Controls.Add(this.AudioDeleteButton);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // AudioBatchButton
            // 
            resources.ApplyResources(this.AudioBatchButton, "AudioBatchButton");
            this.AudioBatchButton.Name = "AudioBatchButton";
            this.AudioBatchButton.UseVisualStyleBackColor = true;
            this.AudioBatchButton.Click += new System.EventHandler(this.AudioBatchButton_Click);
            // 
            // AudioListBox
            // 
            this.AudioListBox.AllowDrop = true;
            this.AudioListBox.FormattingEnabled = true;
            resources.ApplyResources(this.AudioListBox, "AudioListBox");
            this.AudioListBox.Name = "AudioListBox";
            this.AudioListBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.AudioListBox_DragDrop);
            this.AudioListBox.DragOver += new System.Windows.Forms.DragEventHandler(this.AudioListBox_DragOver);
            this.AudioListBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.AudioListBox_MouseDown);
            // 
            // AudioAddButton
            // 
            resources.ApplyResources(this.AudioAddButton, "AudioAddButton");
            this.AudioAddButton.Name = "AudioAddButton";
            this.AudioAddButton.UseVisualStyleBackColor = true;
            this.AudioAddButton.Click += new System.EventHandler(this.AudioAddButton_Click);
            // 
            // AudioClearButton
            // 
            resources.ApplyResources(this.AudioClearButton, "AudioClearButton");
            this.AudioClearButton.Name = "AudioClearButton";
            this.AudioClearButton.UseVisualStyleBackColor = true;
            this.AudioClearButton.Click += new System.EventHandler(this.AudioClearButton_Click);
            // 
            // AudioDeleteButton
            // 
            resources.ApplyResources(this.AudioDeleteButton, "AudioDeleteButton");
            this.AudioDeleteButton.Name = "AudioDeleteButton";
            this.AudioDeleteButton.UseVisualStyleBackColor = true;
            this.AudioDeleteButton.Click += new System.EventHandler(this.AudioDeleteButton_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.OnePicCRFNum);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.AudioCopyCheckBox);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Controls.Add(this.AudioOnePicFPSNum);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Controls.Add(this.AudioOnePicAudioBitrateNum);
            this.groupBox9.Controls.Add(this.AudioOnePicOutputButton);
            this.groupBox9.Controls.Add(this.AudioOnePicButton);
            this.groupBox9.Controls.Add(this.AudioPicAudioButton);
            this.groupBox9.Controls.Add(this.AudioPicButton);
            this.groupBox9.Controls.Add(this.AudioOnePicOutputTextBox);
            this.groupBox9.Controls.Add(this.AudioPicAudioTextBox);
            this.groupBox9.Controls.Add(this.AudioPicTextBox);
            resources.ApplyResources(this.groupBox9, "groupBox9");
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.TabStop = false;
            // 
            // OnePicCRFNum
            // 
            this.OnePicCRFNum.DecimalPlaces = 1;
            this.OnePicCRFNum.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.OnePicCRFNum, "OnePicCRFNum");
            this.OnePicCRFNum.Maximum = new decimal(new int[] {
            51,
            0,
            0,
            0});
            this.OnePicCRFNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.OnePicCRFNum.Name = "OnePicCRFNum";
            this.OnePicCRFNum.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.Name = "label33";
            // 
            // AudioCopyCheckBox
            // 
            resources.ApplyResources(this.AudioCopyCheckBox, "AudioCopyCheckBox");
            this.AudioCopyCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.AudioCopyCheckBox.Name = "AudioCopyCheckBox";
            this.AudioCopyCheckBox.UseVisualStyleBackColor = false;
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            // 
            // AudioOnePicFPSNum
            // 
            resources.ApplyResources(this.AudioOnePicFPSNum, "AudioOnePicFPSNum");
            this.AudioOnePicFPSNum.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.AudioOnePicFPSNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.AudioOnePicFPSNum.Name = "AudioOnePicFPSNum";
            this.AudioOnePicFPSNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            // 
            // AudioOnePicAudioBitrateNum
            // 
            resources.ApplyResources(this.AudioOnePicAudioBitrateNum, "AudioOnePicAudioBitrateNum");
            this.AudioOnePicAudioBitrateNum.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.AudioOnePicAudioBitrateNum.Name = "AudioOnePicAudioBitrateNum";
            this.AudioOnePicAudioBitrateNum.Value = new decimal(new int[] {
            96,
            0,
            0,
            0});
            // 
            // AudioOnePicOutputButton
            // 
            resources.ApplyResources(this.AudioOnePicOutputButton, "AudioOnePicOutputButton");
            this.AudioOnePicOutputButton.Name = "AudioOnePicOutputButton";
            this.AudioOnePicOutputButton.UseVisualStyleBackColor = true;
            this.AudioOnePicOutputButton.Click += new System.EventHandler(this.AudioOnePicOutputButton_Click);
            // 
            // AudioOnePicButton
            // 
            resources.ApplyResources(this.AudioOnePicButton, "AudioOnePicButton");
            this.AudioOnePicButton.Name = "AudioOnePicButton";
            this.AudioOnePicButton.UseVisualStyleBackColor = true;
            this.AudioOnePicButton.Click += new System.EventHandler(this.AudioOnePicButton_Click);
            // 
            // AudioPicAudioButton
            // 
            resources.ApplyResources(this.AudioPicAudioButton, "AudioPicAudioButton");
            this.AudioPicAudioButton.Name = "AudioPicAudioButton";
            this.AudioPicAudioButton.UseVisualStyleBackColor = true;
            this.AudioPicAudioButton.Click += new System.EventHandler(this.AudioPicAudioButton_Click);
            // 
            // AudioPicButton
            // 
            resources.ApplyResources(this.AudioPicButton, "AudioPicButton");
            this.AudioPicButton.Name = "AudioPicButton";
            this.AudioPicButton.UseVisualStyleBackColor = true;
            this.AudioPicButton.Click += new System.EventHandler(this.AudioPicButton_Click);
            // 
            // AudioOnePicOutputTextBox
            // 
            this.AudioOnePicOutputTextBox.AllowDrop = true;
            this.AudioOnePicOutputTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AudioOnePicOutputTextBox.EmptyTextTip = null;
            this.AudioOnePicOutputTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.AudioOnePicOutputTextBox, "AudioOnePicOutputTextBox");
            this.AudioOnePicOutputTextBox.Name = "AudioOnePicOutputTextBox";
            // 
            // AudioPicAudioTextBox
            // 
            this.AudioPicAudioTextBox.AllowDrop = true;
            this.AudioPicAudioTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AudioPicAudioTextBox.EmptyTextTip = null;
            this.AudioPicAudioTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.AudioPicAudioTextBox, "AudioPicAudioTextBox");
            this.AudioPicAudioTextBox.Name = "AudioPicAudioTextBox";
            this.AudioPicAudioTextBox.TextChanged += new System.EventHandler(this.AudioPicAudioTextBox_TextChanged);
            // 
            // AudioPicTextBox
            // 
            this.AudioPicTextBox.AllowDrop = true;
            this.AudioPicTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AudioPicTextBox.EmptyTextTip = null;
            this.AudioPicTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.AudioPicTextBox, "AudioPicTextBox");
            this.AudioPicTextBox.Name = "AudioPicTextBox";
            // 
            // VideoTab
            // 
            this.VideoTab.AllowDrop = true;
            this.VideoTab.Controls.Add(this.x264FramesLabel);
            this.VideoTab.Controls.Add(this.x264SeekLabel);
            this.VideoTab.Controls.Add(this.x264FramesNumericUpDown);
            this.VideoTab.Controls.Add(this.x264SeekNumericUpDown);
            this.VideoTab.Controls.Add(this.btnout4);
            this.VideoTab.Controls.Add(this.MaintainResolutionCheckBox);
            this.VideoTab.Controls.Add(this.DemuxerComboBox);
            this.VideoTab.Controls.Add(this.x264FLVCheckBox);
            this.VideoTab.Controls.Add(this.groupBox1);
            this.VideoTab.Controls.Add(this.x264ShutdownCheckBox);
            this.VideoTab.Controls.Add(this.x264AudioParameterTextBox);
            this.VideoTab.Controls.Add(this.x264SubTextBox);
            this.VideoTab.Controls.Add(this.x264OutTextBox);
            this.VideoTab.Controls.Add(this.x264VideoTextBox);
            this.VideoTab.Controls.Add(this.panel1);
            this.VideoTab.Controls.Add(this.label6);
            this.VideoTab.Controls.Add(this.PresetNameTextBox);
            this.VideoTab.Controls.Add(this.x264AddPresetBtn);
            this.VideoTab.Controls.Add(this.x264DeletePresetBtn);
            this.VideoTab.Controls.Add(this.x264StartBtn);
            this.VideoTab.Controls.Add(this.x264SubBtn);
            this.VideoTab.Controls.Add(this.x264OutBtn);
            this.VideoTab.Controls.Add(this.x264VideoBtn);
            this.VideoTab.Controls.Add(this.label16);
            this.VideoTab.Controls.Add(this.cbx264file);
            this.VideoTab.Controls.Add(this.cbFPS2);
            this.VideoTab.Controls.Add(this.lbFPS2);
            this.VideoTab.Controls.Add(this.x264AudioModeComboBox);
            this.VideoTab.Controls.Add(this.cbX264);
            this.VideoTab.Controls.Add(this.label8);
            this.VideoTab.Controls.Add(this.labelAudio);
            this.VideoTab.Controls.Add(this.label12);
            this.VideoTab.Controls.Add(this.lbcrf);
            this.VideoTab.Controls.Add(this.lbheight);
            this.VideoTab.Controls.Add(this.lbwidth);
            this.VideoTab.Controls.Add(this.numheight);
            this.VideoTab.Controls.Add(this.numwidth);
            this.VideoTab.Controls.Add(this.numcrf);
            this.VideoTab.Controls.Add(this.lbrate);
            this.VideoTab.Controls.Add(this.txth264);
            this.VideoTab.Controls.Add(this.label4);
            this.VideoTab.Controls.Add(this.numrate);
            resources.ApplyResources(this.VideoTab, "VideoTab");
            this.VideoTab.Name = "VideoTab";
            this.VideoTab.UseVisualStyleBackColor = true;
            // 
            // x264FramesLabel
            // 
            resources.ApplyResources(this.x264FramesLabel, "x264FramesLabel");
            this.x264FramesLabel.Name = "x264FramesLabel";
            // 
            // x264SeekLabel
            // 
            resources.ApplyResources(this.x264SeekLabel, "x264SeekLabel");
            this.x264SeekLabel.Name = "x264SeekLabel";
            // 
            // x264FramesNumericUpDown
            // 
            resources.ApplyResources(this.x264FramesNumericUpDown, "x264FramesNumericUpDown");
            this.x264FramesNumericUpDown.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.x264FramesNumericUpDown.Name = "x264FramesNumericUpDown";
            // 
            // x264SeekNumericUpDown
            // 
            resources.ApplyResources(this.x264SeekNumericUpDown, "x264SeekNumericUpDown");
            this.x264SeekNumericUpDown.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.x264SeekNumericUpDown.Name = "x264SeekNumericUpDown";
            // 
            // MaintainResolutionCheckBox
            // 
            resources.ApplyResources(this.MaintainResolutionCheckBox, "MaintainResolutionCheckBox");
            this.MaintainResolutionCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.MaintainResolutionCheckBox.Name = "MaintainResolutionCheckBox";
            this.MaintainResolutionCheckBox.UseVisualStyleBackColor = true;
            this.MaintainResolutionCheckBox.CheckedChanged += new System.EventHandler(this.MaintainResolutionCheckBox_CheckedChanged);
            // 
            // DemuxerComboBox
            // 
            this.DemuxerComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DemuxerComboBox.FormattingEnabled = true;
            this.DemuxerComboBox.Items.AddRange(new object[] {
            resources.GetString("DemuxerComboBox.Items"),
            resources.GetString("DemuxerComboBox.Items1"),
            resources.GetString("DemuxerComboBox.Items2"),
            resources.GetString("DemuxerComboBox.Items3"),
            resources.GetString("DemuxerComboBox.Items4"),
            resources.GetString("DemuxerComboBox.Items5")});
            resources.ApplyResources(this.DemuxerComboBox, "DemuxerComboBox");
            this.DemuxerComboBox.Name = "DemuxerComboBox";
            // 
            // x264FLVCheckBox
            // 
            resources.ApplyResources(this.x264FLVCheckBox, "x264FLVCheckBox");
            this.x264FLVCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.x264FLVCheckBox.Name = "x264FLVCheckBox";
            this.x264FLVCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbDelTmp);
            this.groupBox1.Controls.Add(this.x264OneBatchButton);
            this.groupBox1.Controls.Add(this.x264PathButton);
            this.groupBox1.Controls.Add(this.x264PathTextBox);
            this.groupBox1.Controls.Add(this.lbAuto);
            this.groupBox1.Controls.Add(this.x264BatchClearBtn);
            this.groupBox1.Controls.Add(this.x264BatchSubCheckBox);
            this.groupBox1.Controls.Add(this.x264BatchDeleteBtn);
            this.groupBox1.Controls.Add(this.x264BatchAddBtn);
            this.groupBox1.Controls.Add(this.btnBatchAuto);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // x264OneBatchButton
            // 
            resources.ApplyResources(this.x264OneBatchButton, "x264OneBatchButton");
            this.x264OneBatchButton.Name = "x264OneBatchButton";
            this.x264OneBatchButton.UseVisualStyleBackColor = true;
            this.x264OneBatchButton.Click += new System.EventHandler(this.x264OneBatchButton_Click);
            // 
            // x264PathButton
            // 
            resources.ApplyResources(this.x264PathButton, "x264PathButton");
            this.x264PathButton.Name = "x264PathButton";
            this.x264PathButton.UseVisualStyleBackColor = true;
            this.x264PathButton.Click += new System.EventHandler(this.x264PathButton_Click);
            // 
            // x264PathTextBox
            // 
            this.x264PathTextBox.AllowDrop = true;
            this.x264PathTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.x264PathTextBox.EmptyTextTip = "";
            this.x264PathTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.x264PathTextBox, "x264PathTextBox");
            this.x264PathTextBox.Name = "x264PathTextBox";
            // 
            // lbAuto
            // 
            this.lbAuto.AllowDrop = true;
            this.lbAuto.FormattingEnabled = true;
            resources.ApplyResources(this.lbAuto, "lbAuto");
            this.lbAuto.Name = "lbAuto";
            this.lbAuto.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbAuto_DragDrop);
            this.lbAuto.DragEnter += new System.Windows.Forms.DragEventHandler(this.lbAuto_DragEnter);
            this.lbAuto.DragOver += new System.Windows.Forms.DragEventHandler(this.lbAuto_DragOver);
            this.lbAuto.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbAuto_MouseDown);
            // 
            // x264BatchClearBtn
            // 
            resources.ApplyResources(this.x264BatchClearBtn, "x264BatchClearBtn");
            this.x264BatchClearBtn.Name = "x264BatchClearBtn";
            this.x264BatchClearBtn.UseVisualStyleBackColor = true;
            this.x264BatchClearBtn.Click += new System.EventHandler(this.x264BatchClearBtn_Click);
            // 
            // x264BatchSubCheckBox
            // 
            resources.ApplyResources(this.x264BatchSubCheckBox, "x264BatchSubCheckBox");
            this.x264BatchSubCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.x264BatchSubCheckBox.Name = "x264BatchSubCheckBox";
            this.x264BatchSubCheckBox.UseVisualStyleBackColor = false;
            // 
            // x264BatchDeleteBtn
            // 
            resources.ApplyResources(this.x264BatchDeleteBtn, "x264BatchDeleteBtn");
            this.x264BatchDeleteBtn.Name = "x264BatchDeleteBtn";
            this.x264BatchDeleteBtn.UseVisualStyleBackColor = true;
            this.x264BatchDeleteBtn.Click += new System.EventHandler(this.x264BatchDeleteBtn_Click);
            // 
            // x264BatchAddBtn
            // 
            resources.ApplyResources(this.x264BatchAddBtn, "x264BatchAddBtn");
            this.x264BatchAddBtn.Name = "x264BatchAddBtn";
            this.x264BatchAddBtn.UseVisualStyleBackColor = true;
            this.x264BatchAddBtn.Click += new System.EventHandler(this.x264BatchAddBtn_Click);
            // 
            // btnBatchAuto
            // 
            resources.ApplyResources(this.btnBatchAuto, "btnBatchAuto");
            this.btnBatchAuto.Name = "btnBatchAuto";
            this.btnBatchAuto.UseVisualStyleBackColor = true;
            this.btnBatchAuto.Click += new System.EventHandler(this.btnBatchAuto_Click);
            // 
            // x264ShutdownCheckBox
            // 
            resources.ApplyResources(this.x264ShutdownCheckBox, "x264ShutdownCheckBox");
            this.x264ShutdownCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.x264ShutdownCheckBox.Name = "x264ShutdownCheckBox";
            this.x264ShutdownCheckBox.UseVisualStyleBackColor = false;
            // 
            // x264AudioParameterTextBox
            // 
            this.x264AudioParameterTextBox.AllowDrop = true;
            this.x264AudioParameterTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.x264AudioParameterTextBox.EmptyTextTip = null;
            this.x264AudioParameterTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.x264AudioParameterTextBox, "x264AudioParameterTextBox");
            this.x264AudioParameterTextBox.Name = "x264AudioParameterTextBox";
            // 
            // x264SubTextBox
            // 
            this.x264SubTextBox.AllowDrop = true;
            this.x264SubTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.x264SubTextBox.EmptyTextTip = null;
            this.x264SubTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.x264SubTextBox, "x264SubTextBox");
            this.x264SubTextBox.Name = "x264SubTextBox";
            this.x264SubTextBox.TextChanged += new System.EventHandler(this.x264SubTextBox_TextChanged);
            // 
            // x264OutTextBox
            // 
            this.x264OutTextBox.AllowDrop = true;
            this.x264OutTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.x264OutTextBox.EmptyTextTip = "";
            this.x264OutTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.x264OutTextBox, "x264OutTextBox");
            this.x264OutTextBox.Name = "x264OutTextBox";
            this.x264OutTextBox.TextChanged += new System.EventHandler(this.x264OutTextBox_TextChanged);
            // 
            // x264VideoTextBox
            // 
            this.x264VideoTextBox.AllowDrop = true;
            this.x264VideoTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.x264VideoTextBox.EmptyTextTip = "";
            this.x264VideoTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.x264VideoTextBox, "x264VideoTextBox");
            this.x264VideoTextBox.Name = "x264VideoTextBox";
            this.x264VideoTextBox.TextChanged += new System.EventHandler(this.x264VideoTextBox_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.x264Mode1RadioButton);
            this.panel1.Controls.Add(this.x264Mode3RadioButton);
            this.panel1.Controls.Add(this.x264Mode2RadioButton);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // x264Mode1RadioButton
            // 
            resources.ApplyResources(this.x264Mode1RadioButton, "x264Mode1RadioButton");
            this.x264Mode1RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.x264Mode1RadioButton.Checked = true;
            this.x264Mode1RadioButton.Name = "x264Mode1RadioButton";
            this.x264Mode1RadioButton.TabStop = true;
            this.x264Mode1RadioButton.UseVisualStyleBackColor = false;
            this.x264Mode1RadioButton.CheckedChanged += new System.EventHandler(this.x264Mode1RadioButton_CheckedChanged);
            // 
            // x264Mode3RadioButton
            // 
            resources.ApplyResources(this.x264Mode3RadioButton, "x264Mode3RadioButton");
            this.x264Mode3RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.x264Mode3RadioButton.Name = "x264Mode3RadioButton";
            this.x264Mode3RadioButton.UseVisualStyleBackColor = false;
            this.x264Mode3RadioButton.CheckedChanged += new System.EventHandler(this.x264Mode3RadioButton_CheckedChanged);
            // 
            // x264Mode2RadioButton
            // 
            resources.ApplyResources(this.x264Mode2RadioButton, "x264Mode2RadioButton");
            this.x264Mode2RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.x264Mode2RadioButton.Name = "x264Mode2RadioButton";
            this.x264Mode2RadioButton.UseVisualStyleBackColor = false;
            this.x264Mode2RadioButton.CheckedChanged += new System.EventHandler(this.x264Mode2RadioButton_CheckedChanged);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // PresetNameTextBox
            // 
            this.PresetNameTextBox.AllowDrop = true;
            this.PresetNameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PresetNameTextBox.EmptyTextTip = null;
            this.PresetNameTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.PresetNameTextBox, "PresetNameTextBox");
            this.PresetNameTextBox.Name = "PresetNameTextBox";
            // 
            // x264AddPresetBtn
            // 
            resources.ApplyResources(this.x264AddPresetBtn, "x264AddPresetBtn");
            this.x264AddPresetBtn.Name = "x264AddPresetBtn";
            this.x264AddPresetBtn.UseVisualStyleBackColor = true;
            this.x264AddPresetBtn.Click += new System.EventHandler(this.x264AddPresetBtn_Click);
            // 
            // x264DeletePresetBtn
            // 
            resources.ApplyResources(this.x264DeletePresetBtn, "x264DeletePresetBtn");
            this.x264DeletePresetBtn.Name = "x264DeletePresetBtn";
            this.x264DeletePresetBtn.UseVisualStyleBackColor = true;
            this.x264DeletePresetBtn.Click += new System.EventHandler(this.x264DeletePresetBtn_Click);
            // 
            // x264StartBtn
            // 
            resources.ApplyResources(this.x264StartBtn, "x264StartBtn");
            this.x264StartBtn.Name = "x264StartBtn";
            this.x264StartBtn.UseVisualStyleBackColor = true;
            this.x264StartBtn.Click += new System.EventHandler(this.x264StartBtn_Click);
            // 
            // x264SubBtn
            // 
            resources.ApplyResources(this.x264SubBtn, "x264SubBtn");
            this.x264SubBtn.Name = "x264SubBtn";
            this.x264SubBtn.UseVisualStyleBackColor = true;
            this.x264SubBtn.Click += new System.EventHandler(this.x264SubBtn_Click);
            // 
            // x264OutBtn
            // 
            resources.ApplyResources(this.x264OutBtn, "x264OutBtn");
            this.x264OutBtn.Name = "x264OutBtn";
            this.x264OutBtn.UseVisualStyleBackColor = true;
            this.x264OutBtn.Click += new System.EventHandler(this.x264OutBtn_Click);
            // 
            // x264VideoBtn
            // 
            resources.ApplyResources(this.x264VideoBtn, "x264VideoBtn");
            this.x264VideoBtn.Name = "x264VideoBtn";
            this.x264VideoBtn.UseVisualStyleBackColor = true;
            this.x264VideoBtn.Click += new System.EventHandler(this.x264VideoBtn_Click);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // cbx264file
            // 
            this.cbx264file.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx264file.FormattingEnabled = true;
            resources.ApplyResources(this.cbx264file, "cbx264file");
            this.cbx264file.Name = "cbx264file";
            this.cbx264file.SelectedIndexChanged += new System.EventHandler(this.cbx264file_SelectedIndexChanged);
            // 
            // cbFPS2
            // 
            this.cbFPS2.FormattingEnabled = true;
            this.cbFPS2.Items.AddRange(new object[] {
            resources.GetString("cbFPS2.Items"),
            resources.GetString("cbFPS2.Items1"),
            resources.GetString("cbFPS2.Items2"),
            resources.GetString("cbFPS2.Items3"),
            resources.GetString("cbFPS2.Items4"),
            resources.GetString("cbFPS2.Items5"),
            resources.GetString("cbFPS2.Items6"),
            resources.GetString("cbFPS2.Items7"),
            resources.GetString("cbFPS2.Items8")});
            resources.ApplyResources(this.cbFPS2, "cbFPS2");
            this.cbFPS2.Name = "cbFPS2";
            // 
            // lbFPS2
            // 
            resources.ApplyResources(this.lbFPS2, "lbFPS2");
            this.lbFPS2.Name = "lbFPS2";
            // 
            // x264AudioModeComboBox
            // 
            this.x264AudioModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.x264AudioModeComboBox.FormattingEnabled = true;
            this.x264AudioModeComboBox.Items.AddRange(new object[] {
            resources.GetString("x264AudioModeComboBox.Items"),
            resources.GetString("x264AudioModeComboBox.Items1"),
            resources.GetString("x264AudioModeComboBox.Items2"),
            resources.GetString("x264AudioModeComboBox.Items3"),
            resources.GetString("x264AudioModeComboBox.Items4"),
            resources.GetString("x264AudioModeComboBox.Items5"),
            resources.GetString("x264AudioModeComboBox.Items6")});
            resources.ApplyResources(this.x264AudioModeComboBox, "x264AudioModeComboBox");
            this.x264AudioModeComboBox.Name = "x264AudioModeComboBox";
            this.x264AudioModeComboBox.SelectedIndexChanged += new System.EventHandler(this.x264AudioModeComboBox_SelectedIndexChanged);
            // 
            // cbX264
            // 
            this.cbX264.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbX264.FormattingEnabled = true;
            resources.ApplyResources(this.cbX264, "cbX264");
            this.cbX264.Name = "cbX264";
            this.cbX264.SelectedIndexChanged += new System.EventHandler(this.cbX264_SelectedIndexChanged);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // labelAudio
            // 
            resources.ApplyResources(this.labelAudio, "labelAudio");
            this.labelAudio.Name = "labelAudio";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // lbcrf
            // 
            resources.ApplyResources(this.lbcrf, "lbcrf");
            this.lbcrf.Name = "lbcrf";
            // 
            // lbheight
            // 
            resources.ApplyResources(this.lbheight, "lbheight");
            this.lbheight.Name = "lbheight";
            // 
            // lbwidth
            // 
            resources.ApplyResources(this.lbwidth, "lbwidth");
            this.lbwidth.Name = "lbwidth";
            // 
            // numheight
            // 
            resources.ApplyResources(this.numheight, "numheight");
            this.numheight.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numheight.Name = "numheight";
            // 
            // numwidth
            // 
            resources.ApplyResources(this.numwidth, "numwidth");
            this.numwidth.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numwidth.Name = "numwidth";
            // 
            // numcrf
            // 
            this.numcrf.DecimalPlaces = 1;
            this.numcrf.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.numcrf, "numcrf");
            this.numcrf.Maximum = new decimal(new int[] {
            51,
            0,
            0,
            0});
            this.numcrf.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numcrf.Name = "numcrf";
            this.numcrf.Value = new decimal(new int[] {
            235,
            0,
            0,
            65536});
            // 
            // lbrate
            // 
            resources.ApplyResources(this.lbrate, "lbrate");
            this.lbrate.Name = "lbrate";
            // 
            // txth264
            // 
            this.txth264.AllowDrop = true;
            this.txth264.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txth264.EmptyTextTip = null;
            this.txth264.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.txth264, "txth264");
            this.txth264.Name = "txth264";
            this.txth264.TextChanged += new System.EventHandler(this.txth264_TextChanged);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // numrate
            // 
            resources.ApplyResources(this.numrate, "numrate");
            this.numrate.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numrate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numrate.Name = "numrate";
            this.numrate.Value = new decimal(new int[] {
            800,
            0,
            0,
            0});
            // 
            // HelpTab
            // 
            this.HelpTab.Controls.Add(this.DonateButton);
            this.HelpTab.Controls.Add(this.HelpTextBox);
            this.HelpTab.Controls.Add(this.HomePageBtn);
            this.HelpTab.Controls.Add(this.AboutBtn);
            this.HelpTab.Controls.Add(this.linkLabel4);
            this.HelpTab.Controls.Add(this.linkLabel2);
            this.HelpTab.Controls.Add(this.linkLabel1);
            resources.ApplyResources(this.HelpTab, "HelpTab");
            this.HelpTab.Name = "HelpTab";
            this.HelpTab.UseVisualStyleBackColor = true;
            // 
            // DonateButton
            // 
            resources.ApplyResources(this.DonateButton, "DonateButton");
            this.DonateButton.Name = "DonateButton";
            this.DonateButton.UseVisualStyleBackColor = true;
            this.DonateButton.Click += new System.EventHandler(this.DonateButton_Click);
            // 
            // HelpTextBox
            // 
            this.HelpTextBox.AllowDrop = true;
            this.HelpTextBox.BackColor = System.Drawing.Color.White;
            this.HelpTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HelpTextBox.EmptyTextTip = null;
            this.HelpTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.HelpTextBox, "HelpTextBox");
            this.HelpTextBox.Name = "HelpTextBox";
            this.HelpTextBox.ReadOnly = true;
            // 
            // HomePageBtn
            // 
            resources.ApplyResources(this.HomePageBtn, "HomePageBtn");
            this.HomePageBtn.Name = "HomePageBtn";
            this.HomePageBtn.UseVisualStyleBackColor = true;
            this.HomePageBtn.Click += new System.EventHandler(this.HomePageBtn_Click);
            // 
            // AboutBtn
            // 
            resources.ApplyResources(this.AboutBtn, "AboutBtn");
            this.AboutBtn.Name = "AboutBtn";
            this.AboutBtn.UseVisualStyleBackColor = true;
            this.AboutBtn.Click += new System.EventHandler(this.AboutBtn_Click);
            // 
            // linkLabel4
            // 
            resources.ApplyResources(this.linkLabel4, "linkLabel4");
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.TabStop = true;
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // linkLabel2
            // 
            resources.ApplyResources(this.linkLabel2, "linkLabel2");
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.TabStop = true;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            resources.ApplyResources(this.linkLabel1, "linkLabel1");
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.TabStop = true;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // AudioTab
            // 
            this.AudioTab.AllowDrop = true;
            this.AudioTab.Controls.Add(this.VideoTab);
            this.AudioTab.Controls.Add(this.tabNeroAAC);
            this.AudioTab.Controls.Add(this.MiscTab);
            this.AudioTab.Controls.Add(this.MuxTab);
            this.AudioTab.Controls.Add(this.ExtractTab);
            this.AudioTab.Controls.Add(this.AVSTab);
            this.AudioTab.Controls.Add(this.MediaInfoTab);
            this.AudioTab.Controls.Add(this.SetupTabPage);
            this.AudioTab.Controls.Add(this.HelpTab);
            this.AudioTab.Cursor = System.Windows.Forms.Cursors.Default;
            this.AudioTab.HotTrack = true;
            resources.ApplyResources(this.AudioTab, "AudioTab");
            this.AudioTab.Name = "AudioTab";
            this.AudioTab.SelectedIndex = 0;
            // 
            // MiscTab
            // 
            this.MiscTab.Controls.Add(this.groupBox11);
            this.MiscTab.Controls.Add(this.groupBox10);
            this.MiscTab.Controls.Add(this.groupBox9);
            resources.ApplyResources(this.MiscTab, "MiscTab");
            this.MiscTab.Name = "MiscTab";
            this.MiscTab.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label37);
            this.groupBox11.Controls.Add(this.label36);
            this.groupBox11.Controls.Add(this.BlackBitrateNum);
            this.groupBox11.Controls.Add(this.label35);
            this.groupBox11.Controls.Add(this.BlackSecondComboBox);
            this.groupBox11.Controls.Add(this.label34);
            this.groupBox11.Controls.Add(this.BlackCRFNum);
            this.groupBox11.Controls.Add(this.label32);
            this.groupBox11.Controls.Add(this.BlackNoPicCheckBox);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Controls.Add(this.BlackFPSNum);
            this.groupBox11.Controls.Add(this.BlackPicButton);
            this.groupBox11.Controls.Add(this.BlackPicTextBox);
            this.groupBox11.Controls.Add(this.BlackStartButton);
            this.groupBox11.Controls.Add(this.BlackOutputButton);
            this.groupBox11.Controls.Add(this.BlackVideoButton);
            this.groupBox11.Controls.Add(this.BlackOutputTextBox);
            this.groupBox11.Controls.Add(this.BlackVideoTextBox);
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            // 
            // BlackBitrateNum
            // 
            resources.ApplyResources(this.BlackBitrateNum, "BlackBitrateNum");
            this.BlackBitrateNum.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.BlackBitrateNum.Name = "BlackBitrateNum";
            this.BlackBitrateNum.Value = new decimal(new int[] {
            900,
            0,
            0,
            0});
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.Name = "label35";
            // 
            // BlackSecondComboBox
            // 
            this.BlackSecondComboBox.FormattingEnabled = true;
            this.BlackSecondComboBox.Items.AddRange(new object[] {
            resources.GetString("BlackSecondComboBox.Items"),
            resources.GetString("BlackSecondComboBox.Items1"),
            resources.GetString("BlackSecondComboBox.Items2"),
            resources.GetString("BlackSecondComboBox.Items3"),
            resources.GetString("BlackSecondComboBox.Items4")});
            resources.ApplyResources(this.BlackSecondComboBox, "BlackSecondComboBox");
            this.BlackSecondComboBox.Name = "BlackSecondComboBox";
            this.BlackSecondComboBox.SelectedIndexChanged += new System.EventHandler(this.BlackSecondComboBox_SelectedIndexChanged);
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.Name = "label34";
            // 
            // BlackCRFNum
            // 
            this.BlackCRFNum.DecimalPlaces = 1;
            this.BlackCRFNum.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.BlackCRFNum, "BlackCRFNum");
            this.BlackCRFNum.Maximum = new decimal(new int[] {
            51,
            0,
            0,
            0});
            this.BlackCRFNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BlackCRFNum.Name = "BlackCRFNum";
            this.BlackCRFNum.Value = new decimal(new int[] {
            51,
            0,
            0,
            0});
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            // 
            // BlackNoPicCheckBox
            // 
            resources.ApplyResources(this.BlackNoPicCheckBox, "BlackNoPicCheckBox");
            this.BlackNoPicCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.BlackNoPicCheckBox.Checked = true;
            this.BlackNoPicCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BlackNoPicCheckBox.Name = "BlackNoPicCheckBox";
            this.BlackNoPicCheckBox.UseVisualStyleBackColor = false;
            this.BlackNoPicCheckBox.CheckedChanged += new System.EventHandler(this.BlackNoPicCheckBox_CheckedChanged);
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // BlackFPSNum
            // 
            resources.ApplyResources(this.BlackFPSNum, "BlackFPSNum");
            this.BlackFPSNum.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.BlackFPSNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BlackFPSNum.Name = "BlackFPSNum";
            this.BlackFPSNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // BlackPicButton
            // 
            resources.ApplyResources(this.BlackPicButton, "BlackPicButton");
            this.BlackPicButton.Name = "BlackPicButton";
            this.BlackPicButton.UseVisualStyleBackColor = true;
            this.BlackPicButton.Click += new System.EventHandler(this.BlackPicButton_Click);
            // 
            // BlackPicTextBox
            // 
            this.BlackPicTextBox.AllowDrop = true;
            this.BlackPicTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BlackPicTextBox.EmptyTextTip = null;
            this.BlackPicTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.BlackPicTextBox, "BlackPicTextBox");
            this.BlackPicTextBox.Name = "BlackPicTextBox";
            // 
            // BlackStartButton
            // 
            resources.ApplyResources(this.BlackStartButton, "BlackStartButton");
            this.BlackStartButton.Name = "BlackStartButton";
            this.BlackStartButton.UseVisualStyleBackColor = true;
            this.BlackStartButton.Click += new System.EventHandler(this.BlackStartButton_Click);
            // 
            // BlackOutputButton
            // 
            resources.ApplyResources(this.BlackOutputButton, "BlackOutputButton");
            this.BlackOutputButton.Name = "BlackOutputButton";
            this.BlackOutputButton.UseVisualStyleBackColor = true;
            this.BlackOutputButton.Click += new System.EventHandler(this.BlackOutputButton_Click);
            // 
            // BlackVideoButton
            // 
            resources.ApplyResources(this.BlackVideoButton, "BlackVideoButton");
            this.BlackVideoButton.Name = "BlackVideoButton";
            this.BlackVideoButton.UseVisualStyleBackColor = true;
            this.BlackVideoButton.Click += new System.EventHandler(this.BlackVideoButton_Click);
            // 
            // BlackOutputTextBox
            // 
            this.BlackOutputTextBox.AllowDrop = true;
            this.BlackOutputTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BlackOutputTextBox.EmptyTextTip = null;
            this.BlackOutputTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.BlackOutputTextBox, "BlackOutputTextBox");
            this.BlackOutputTextBox.Name = "BlackOutputTextBox";
            // 
            // BlackVideoTextBox
            // 
            this.BlackVideoTextBox.AllowDrop = true;
            this.BlackVideoTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BlackVideoTextBox.EmptyTextTip = null;
            this.BlackVideoTextBox.EmptyTextTipColor = System.Drawing.Color.DarkGray;
            resources.ApplyResources(this.BlackVideoTextBox, "BlackVideoTextBox");
            this.BlackVideoTextBox.Name = "BlackVideoTextBox";
            this.BlackVideoTextBox.TextChanged += new System.EventHandler(this.BlackVideoTextBox_TextChanged);
            // 
            // SetupTabPage
            // 
            this.SetupTabPage.Controls.Add(this.qqButton1);
            this.SetupTabPage.Controls.Add(this.x264PriorityComboBox);
            this.SetupTabPage.Controls.Add(this.label11);
            this.SetupTabPage.Controls.Add(this.languageComboBox);
            this.SetupTabPage.Controls.Add(this.label26);
            this.SetupTabPage.Controls.Add(this.btnMP4);
            this.SetupTabPage.Controls.Add(this.btnflv);
            this.SetupTabPage.Controls.Add(this.DeleteLogButton);
            this.SetupTabPage.Controls.Add(this.ViewLogButton);
            resources.ApplyResources(this.SetupTabPage, "SetupTabPage");
            this.SetupTabPage.Name = "SetupTabPage";
            this.SetupTabPage.UseVisualStyleBackColor = true;
            // 
            // qqButton1
            // 
            resources.ApplyResources(this.qqButton1, "qqButton1");
            this.qqButton1.Name = "qqButton1";
            this.qqButton1.UseVisualStyleBackColor = true;
            // 
            // x264PriorityComboBox
            // 
            this.x264PriorityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.x264PriorityComboBox.FormattingEnabled = true;
            this.x264PriorityComboBox.Items.AddRange(new object[] {
            resources.GetString("x264PriorityComboBox.Items"),
            resources.GetString("x264PriorityComboBox.Items1"),
            resources.GetString("x264PriorityComboBox.Items2"),
            resources.GetString("x264PriorityComboBox.Items3"),
            resources.GetString("x264PriorityComboBox.Items4"),
            resources.GetString("x264PriorityComboBox.Items5")});
            resources.ApplyResources(this.x264PriorityComboBox, "x264PriorityComboBox");
            this.x264PriorityComboBox.Name = "x264PriorityComboBox";
            this.x264PriorityComboBox.SelectedIndexChanged += new System.EventHandler(this.x264PriorityComboBox_SelectedIndexChanged);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // languageComboBox
            // 
            this.languageComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.languageComboBox.FormattingEnabled = true;
            this.languageComboBox.Items.AddRange(new object[] {
            resources.GetString("languageComboBox.Items"),
            resources.GetString("languageComboBox.Items1"),
            resources.GetString("languageComboBox.Items2")});
            resources.ApplyResources(this.languageComboBox, "languageComboBox");
            this.languageComboBox.Name = "languageComboBox";
            this.languageComboBox.SelectedIndexChanged += new System.EventHandler(this.languageComboBox_SelectedIndexChanged);
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // btnMP4
            // 
            resources.ApplyResources(this.btnMP4, "btnMP4");
            this.btnMP4.Name = "btnMP4";
            this.btnMP4.UseVisualStyleBackColor = true;
            this.btnMP4.Click += new System.EventHandler(this.btnMP4_Click);
            // 
            // btnflv
            // 
            resources.ApplyResources(this.btnflv, "btnflv");
            this.btnflv.Name = "btnflv";
            this.btnflv.UseVisualStyleBackColor = true;
            this.btnflv.Click += new System.EventHandler(this.btnflv_Click);
            // 
            // DeleteLogButton
            // 
            resources.ApplyResources(this.DeleteLogButton, "DeleteLogButton");
            this.DeleteLogButton.Name = "DeleteLogButton";
            this.DeleteLogButton.UseVisualStyleBackColor = true;
            this.DeleteLogButton.Click += new System.EventHandler(this.DeleteLogButton_Click);
            // 
            // ViewLogButton
            // 
            resources.ApplyResources(this.ViewLogButton, "ViewLogButton");
            this.ViewLogButton.Name = "ViewLogButton";
            this.ViewLogButton.UseVisualStyleBackColor = true;
            this.ViewLogButton.Click += new System.EventHandler(this.ViewLogButton_Click);
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.AudioTab);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.MediaInfoTab.ResumeLayout(false);
            this.MediaInfoTab.PerformLayout();
            this.AVSTab.ResumeLayout(false);
            this.AVSTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrimEndNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrimStartNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelsNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders4NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders3NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders2NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpenNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBorders1NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AVSHeightNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AVSWidthNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakContrastNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakBrightnessNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakSaturationNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TweakChromaNumericUpDown)).EndInit();
            this.ExtractTab.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.MuxTab.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabNeroAAC.ResumeLayout(false);
            this.NeroAACGroupBox.ResumeLayout(false);
            this.NeroAACGroupBox.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numq)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OnePicCRFNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AudioOnePicFPSNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AudioOnePicAudioBitrateNum)).EndInit();
            this.VideoTab.ResumeLayout(false);
            this.VideoTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.x264FramesNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x264SeekNumericUpDown)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numheight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numwidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numcrf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numrate)).EndInit();
            this.HelpTab.ResumeLayout(false);
            this.HelpTab.PerformLayout();
            this.AudioTab.ResumeLayout(false);
            this.MiscTab.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BlackBitrateNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackCRFNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackFPSNum)).EndInit();
            this.SetupTabPage.ResumeLayout(false);
            this.SetupTabPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private ControlExs.QQButton btnClip;
        private System.Windows.Forms.MaskedTextBox maske;
        private System.Windows.Forms.MaskedTextBox maskb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private ControlExs.QQTextBox txtout5;
        private ControlExs.QQTextBox txtvideo4;
        private ControlExs.QQButton btnout5;
        private ControlExs.QQButton btnvideo4;
        private ControlExs.QQCheckBox cbDelTmp;
        private ControlExs.QQButton btnout4;
        private System.Windows.Forms.TabPage MediaInfoTab;
        private ControlExs.QQButton btnMIopen;
        private ControlExs.QQButton btnMIplay;
        private ControlExs.QQButton btnMIcopy;
        private System.Windows.Forms.TextBox txtMI;
        private System.Windows.Forms.TabPage AVSTab;
        private System.Windows.Forms.Label label2;
        private ControlExs.QQButton button9;
        private ControlExs.QQButton button6;
        private ControlExs.QQButton btnpreview9;
        private ControlExs.QQButton btnAVSone;
        private ControlExs.QQButton btnAVS9;
        private ControlExs.QQTextBox txtAVS;
        private ControlExs.QQTextBox txtvideo9;
        private ControlExs.QQTextBox txtout9;
        private ControlExs.QQTextBox txtsub9;
        private ControlExs.QQButton btnvideo9;
        private ControlExs.QQButton btnout9;
        private ControlExs.QQButton btnsub9;
        private System.Windows.Forms.TabPage ExtractTab;
        private System.Windows.Forms.GroupBox groupBox7;
        private ControlExs.QQButton btnextract7;
        private ControlExs.QQButton btnvideo7;
        private ControlExs.QQTextBox txtvideo6;
        private System.Windows.Forms.GroupBox groupBox6;
        private ControlExs.QQButton btnvextract8;
        private ControlExs.QQButton btnvideo8;
        private ControlExs.QQTextBox txtvideo8;
        private ControlExs.QQButton btnaextract8;
        private System.Windows.Forms.GroupBox groupBox5;
        private ControlExs.QQTextBox ExtractMP4TextBox;
        private ControlExs.QQButton btnaextract3;
        private ControlExs.QQButton ExtractMP4Button;
        private ControlExs.QQButton btnvextract;
        private ControlExs.QQButton btnaextract;
        private ControlExs.QQButton btnaextract2;
        private System.Windows.Forms.TabPage MuxTab;
        private System.Windows.Forms.GroupBox groupBox8;
        private ControlExs.QQTextBox txtvideo5;
        private ControlExs.QQButton button4;
        private ControlExs.QQTextBox txtsub;
        private ControlExs.QQButton button3;
        private ControlExs.QQTextBox txtaudio3;
        private ControlExs.QQButton button5;
        private ControlExs.QQTextBox txtout6;
        private ControlExs.QQButton button2;
        private ControlExs.QQButton button7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox lbffmpeg;
        private ControlExs.QQButton btnffmpegAdd;
        private ControlExs.QQButton btnffmpegClear;
        private System.Windows.Forms.Label label3;
        private ControlExs.QQButton btnffmpegDel;
        private ControlExs.QQButton btnBatchMP4;
        private ControlExs.QQButton btnBatchFLV;
        private System.Windows.Forms.GroupBox groupBox3;
        private ControlExs.QQTextBox txtvideo;
        private ControlExs.QQButton btnvideo;
        private ControlExs.QQButton btnmux;
        private System.Windows.Forms.ComboBox cbFPS;
        private ControlExs.QQButton btnaudio;
        private ControlExs.QQButton btnout;
        private ControlExs.QQTextBox txtaudio;
        private System.Windows.Forms.Label label14;
        private ControlExs.QQTextBox txtout;
        private ControlExs.QQButton btnflv;
        private ControlExs.QQButton btnMP4;
        private System.Windows.Forms.TabPage tabNeroAAC;
        private System.Windows.Forms.Panel panel2;
        private ControlExs.QQCheckBox cbwavtemp;
        private System.Windows.Forms.Label lbaackbps;
        private System.Windows.Forms.Label lbaacrate;
        private System.Windows.Forms.NumericUpDown numq;
        private ControlExs.QQButton btnaac;
        private ControlExs.QQButton btnout3;
        private ControlExs.QQButton btnaudio2;
        private System.Windows.Forms.GroupBox groupBox2;
        private ControlExs.QQTextBox txtout3;
        private ControlExs.QQTextBox txtaudio2;
        private ControlExs.QQTextBox txtNeroaac;
        private System.Windows.Forms.TabPage VideoTab;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lbAuto;
        private ControlExs.QQButton x264BatchClearBtn;
        private ControlExs.QQCheckBox x264BatchSubCheckBox;
        private ControlExs.QQButton x264BatchDeleteBtn;
        private ControlExs.QQButton btnBatchAuto;
        private ControlExs.QQButton x264BatchAddBtn;
        private ControlExs.QQCheckBox x264ShutdownCheckBox;
        private ControlExs.QQTextBox x264AudioParameterTextBox;
        private ControlExs.QQTextBox x264SubTextBox;
        private ControlExs.QQTextBox x264OutTextBox;
        private ControlExs.QQTextBox x264VideoTextBox;
        private ControlExs.QQTextBox PresetNameTextBox;
        private ControlExs.QQTextBox txth264;
        private ControlExs.QQButton x264AddPresetBtn;
        private ControlExs.QQButton x264DeletePresetBtn;
        private ControlExs.QQButton x264StartBtn;
        private ControlExs.QQButton x264SubBtn;
        private ControlExs.QQButton x264OutBtn;
        private ControlExs.QQButton x264VideoBtn;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbx264file;
        private System.Windows.Forms.ComboBox cbFPS2;
        private System.Windows.Forms.Label lbFPS2;
        private System.Windows.Forms.ComboBox x264AudioModeComboBox;
        private System.Windows.Forms.ComboBox cbX264;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelAudio;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private ControlExs.QQRadioButton x264Mode1RadioButton;
        private ControlExs.QQRadioButton x264Mode3RadioButton;
        private ControlExs.QQRadioButton x264Mode2RadioButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbcrf;
        private System.Windows.Forms.Label lbheight;
        private System.Windows.Forms.Label lbwidth;
        private System.Windows.Forms.NumericUpDown numheight;
        private System.Windows.Forms.NumericUpDown numwidth;
        private System.Windows.Forms.NumericUpDown numrate;
        private System.Windows.Forms.NumericUpDown numcrf;
        private System.Windows.Forms.Label lbrate;
        private System.Windows.Forms.TabPage HelpTab;
        private ControlExs.QQTextBox HelpTextBox;
        private ControlExs.QQButton HomePageBtn;
        private ControlExs.QQButton AboutBtn;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TabControl AudioTab;
        private ControlExs.QQRadioButton AudioBitrateRadioButton;
        private ControlExs.QQRadioButton AudioCustomizeRadioButton;
        private ControlExs.QQCheckBox x264FLVCheckBox;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ListBox AudioListBox;
        private ControlExs.QQButton AudioAddButton;
        private ControlExs.QQButton AudioClearButton;
        private ControlExs.QQButton AudioDeleteButton;
        private ControlExs.QQButton AudioBatchButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown AVSHeightNumericUpDown;
        private System.Windows.Forms.NumericUpDown AVSWidthNumericUpDown;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown TweakContrastNumericUpDown;
        private System.Windows.Forms.NumericUpDown TweakBrightnessNumericUpDown;
        private System.Windows.Forms.NumericUpDown TweakSaturationNumericUpDown;
        private System.Windows.Forms.NumericUpDown TweakChromaNumericUpDown;
        private ControlExs.QQCheckBox TrimCheckBox;
        private ControlExs.QQCheckBox SharpenCheckBox;
        private ControlExs.QQCheckBox AddBordersCheckBox;
        private ControlExs.QQCheckBox LanczosResizeCheckBox;
        private ControlExs.QQCheckBox TweakCheckBox;
        private ControlExs.QQCheckBox UndotCheckBox;
        private System.Windows.Forms.NumericUpDown LevelsNumericUpDown;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown AddBorders4NumericUpDown;
        private System.Windows.Forms.NumericUpDown AddBorders3NumericUpDown;
        private System.Windows.Forms.NumericUpDown AddBorders2NumericUpDown;
        private System.Windows.Forms.NumericUpDown SharpenNumericUpDown;
        private ControlExs.QQCheckBox LevelsCheckBox;
        private ControlExs.QQCheckBox CropCheckBox;
        private System.Windows.Forms.NumericUpDown AddBorders1NumericUpDown;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private ControlExs.QQTextBox AVSCropTextBox;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown TrimEndNumericUpDown;
        private System.Windows.Forms.NumericUpDown TrimStartNumericUpDown;
        private ControlExs.QQCheckBox AVSSubCheckBox;
        private System.Windows.Forms.ComboBox DemuxerComboBox;
        private ControlExs.QQButton DeleteLogButton;
        private ControlExs.QQButton ViewLogButton;
        private ControlExs.QQButton x264PathButton;
        private ControlExs.QQTextBox x264PathTextBox;
        private System.Windows.Forms.GroupBox NeroAACGroupBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox AudioEncoderComboBox;
        private System.Windows.Forms.TabPage SetupTabPage;
        private ControlExs.QQButton qqButton1;
        private System.Windows.Forms.ComboBox languageComboBox;
        private System.Windows.Forms.Label label26;
        private ControlExs.QQButton x264OneBatchButton;
        private ControlExs.QQButton DonateButton;
        private ControlExs.QQButton AVSSaveButton;
        private ControlExs.QQButton MuxReplaceAudioButton;
        private System.Windows.Forms.Label x264FramesLabel;
        private System.Windows.Forms.Label x264SeekLabel;
        private System.Windows.Forms.NumericUpDown x264FramesNumericUpDown;
        private System.Windows.Forms.NumericUpDown x264SeekNumericUpDown;
        private System.Windows.Forms.ComboBox x264PriorityComboBox;
        private System.Windows.Forms.Label label11;
        private ControlExs.QQCheckBox MaintainResolutionCheckBox;
        private ControlExs.QQButton MkvExtract4Button;
        private ControlExs.QQButton MkvExtract3Button;
        private ControlExs.QQButton MkvExtract2Button;
        private ControlExs.QQButton MkvExtract1Button;
        private System.Windows.Forms.GroupBox groupBox9;
        private ControlExs.QQButton AudioOnePicButton;
        private ControlExs.QQButton AudioPicAudioButton;
        private ControlExs.QQButton AudioPicButton;
        private ControlExs.QQTextBox AudioPicAudioTextBox;
        private ControlExs.QQTextBox AudioPicTextBox;
        private ControlExs.QQButton AudioOnePicOutputButton;
        private ControlExs.QQTextBox AudioOnePicOutputTextBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown AudioOnePicAudioBitrateNum;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown AudioOnePicFPSNum;
        private ControlExs.QQCheckBox AudioCopyCheckBox;
        private System.Windows.Forms.TabPage MiscTab;
        private System.Windows.Forms.GroupBox groupBox11;
        private ControlExs.QQButton BlackStartButton;
        private ControlExs.QQButton BlackOutputButton;
        private ControlExs.QQButton BlackVideoButton;
        private ControlExs.QQTextBox BlackOutputTextBox;
        private ControlExs.QQTextBox BlackVideoTextBox;
        private ControlExs.QQButton BlackPicButton;
        private ControlExs.QQTextBox BlackPicTextBox;
        private System.Windows.Forms.NumericUpDown OnePicCRFNum;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown BlackCRFNum;
        private System.Windows.Forms.Label label32;
        private ControlExs.QQCheckBox BlackNoPicCheckBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown BlackFPSNum;
        private System.Windows.Forms.ComboBox BlackSecondComboBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown BlackBitrateNum;
    }
}

